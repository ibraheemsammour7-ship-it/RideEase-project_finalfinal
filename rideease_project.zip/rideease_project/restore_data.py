from rentals.models import Car, Booking
from django.utils import timezone
from datetime import date

# ====== بيانات السيارات ======
car = Car.objects.create(
    id=3,
    brand="Kia",
    model="Sportage",
    year=2021,
    price_per_day=40.00,
    location="Amman",
    is_available=True,
    created_at=timezone.now()
)

# ====== بيانات الحجز ======
booking = Booking.objects.create(
    id=5,
    customer_name="anas",
    customer_email="anasalbalsheh@gmail.com",
    customer_phone="0798888888",
    start_date=date(2025, 5, 13),
    end_date=date(2025, 5, 21),
    created_at=timezone.now(),
    car=car
)

print("✅ Data restored successfully.")
