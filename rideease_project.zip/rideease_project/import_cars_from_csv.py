import os
import django
import csv

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rideease_backend.settings')
django.setup()

from django.contrib.auth.models import User
from rentals.models import Car, Office

file_path = 'Generated_Cars_Data_WithOwners.csv'



with open(file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    count = 0
    for row in reader:
        try:
            user = User.objects.get(username=row['owner_username'])
            office = Office.objects.filter(owner=user).first()
            if not office:
                print(f"❌ Office not found for {user.username}")
                continue

            car, created = Car.objects.get_or_create(
                brand=row['brand'],
                model=row['model'],
                year=int(float(row['year'])),
                price_per_day=float(row['price_per_day']),
                location=row['location'],
                fuel_type=row['fuel_type'],
                transmission_type=row['transmission_type'],
                number_of_seats=int(row['number_of_seats']),
                engine_size=float(row['engine_size']) if row['engine_size'] else None,
                battery_range=int(row['battery_range']) if row['battery_range'] else None,
                color=row['color'],
                body_type=row['body_type'],
                shipping_available=row['shipping_available'].strip().lower() == 'true',
                office=office,
                is_available=True
            )
            count += 1
        except Exception as e:
            print(f"❌ Error importing car: {e}")

print(f"✅ Imported {count} cars from CSV")
