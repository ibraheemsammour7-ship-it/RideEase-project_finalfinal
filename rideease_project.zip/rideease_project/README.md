# RideEase - Car Rental Platform

A full-featured car rental platform built with Django, featuring office management, car listings, bookings, payments, reviews, and more.

## 🚀 Quick Setup (For New Users)

### Prerequisites
- Python 3.10 or higher
- pip (Python package manager)

### Step 1: Clone/Extract the Project
Extract this project folder to your desired location.

### Step 2: Create Virtual Environment
Open a terminal in the project folder and run:

```bash
# Windows
python -m venv .venv
.venv\Scripts\activate

# macOS/Linux
python3 -m venv .venv
source .venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Apply Database Migrations
```bash
python manage.py migrate
```

### Step 5: Create a Superuser (Admin Account)
```bash
python manage.py createsuperuser
```
Follow the prompts to set up your admin account.

### Step 6: Run the Development Server
```bash
python manage.py runserver
```

Visit **http://127.0.0.1:8000** in your browser.

---

## 📁 Project Structure

```
rideease_project/
├── manage.py                 # Django management script
├── requirements.txt          # Python dependencies
├── db.sqlite3               # SQLite database (development)
├── rideease_backend/        # Main Django settings
│   ├── settings.py          # Configuration
│   ├── urls.py              # URL routing
│   └── wsgi.py              # WSGI application
├── rentals/                 # Main application
│   ├── models.py            # Database models
│   ├── views.py             # View logic
│   ├── forms.py             # Form definitions
│   ├── admin.py             # Admin configuration
│   ├── templates/           # HTML templates
│   └── api/                 # REST API endpoints
├── static/                  # Static files (CSS, JS)
├── media/                   # User uploaded files
└── templates/               # Base templates
```

---

## 🔑 Default Accounts

If using the included database:
- **Admin Panel**: http://127.0.0.1:8000/admin/

---

## ⚙️ Configuration

### Environment Variables (Optional for Production)
Create a `.env` file in the project root:

```env
DJANGO_SECRET_KEY=your-secret-key-here
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
```

### Database
- **Development**: SQLite (default, included)
- **Production**: Configure PostgreSQL in `settings.py`

---

## 🛠️ Common Commands

```bash
# Run development server
python manage.py runserver

# Create new migrations after model changes
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Collect static files (production)
python manage.py collectstatic

# Create superuser
python manage.py createsuperuser

# Run tests
python manage.py test
```

---

## 📋 Features

- **User Authentication**: Registration, login, password reset
- **Multi-role Support**: Customers, Office Owners, Admins
- **Car Management**: Add, edit, delete car listings with images
- **Booking System**: Book cars, manage reservations
- **Payment Processing**: Simulated payments with receipts
- **Reviews & Ratings**: Rate cars and offices
- **Favorites**: Save favorite cars
- **Notifications**: In-app notification system
- **Analytics Dashboard**: Stats for admins and owners
- **Multi-language**: English and Arabic support
- **Dark Mode**: Built-in dark theme

---

## 🔧 Troubleshooting

### "Module not found" errors
Ensure virtual environment is activated and dependencies installed:
```bash
pip install -r requirements.txt
```

### Database errors
Reset migrations if needed:
```bash
python manage.py migrate --run-syncdb
```

### Static files not loading
Collect static files:
```bash
python manage.py collectstatic --noinput
```

### Images not displaying
Ensure `media/` folder exists and has proper permissions.

---

## 📝 Important Notes

1. **Database included**: The `db.sqlite3` file contains sample data. Delete it and run migrations for a fresh start.
2. **Media files**: User uploads are stored in the `media/` folder.
3. **Secret key**: Change `SECRET_KEY` in `settings.py` for production.
4. **Debug mode**: Set `DEBUG=False` in production.

---

## 📧 Support

For issues, check the Django documentation: https://docs.djangoproject.com/
