"""
Tests for RideEase Rental Platform

Covers core functionality:
- User registration and authentication
- Car listing and search
- Booking creation and management
- Payment processing
- Review submission
"""

from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework.test import APITestCase, APIClient
from rest_framework.authtoken.models import Token
from rest_framework import status
from decimal import Decimal
from datetime import date, timedelta

from .models import (
    Profile, Office, Car, Booking, Payment, Review, Favorite,
    Notification, SupportTicket, FAQItem, Discount
)


class UserAuthTests(APITestCase):
    """Test user registration and authentication"""
    
    def setUp(self):
        self.client = APIClient()
        self.register_url = '/api/auth/register/'
        self.login_url = '/api/auth/login/'
    
    def test_user_registration(self):
        """Test user registration creates user and profile"""
        data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'email': 'john@example.com',
            'password': 'SecurePass123!',
            'password_confirm': 'SecurePass123!',
            'user_type': 'customer',
            'accept_terms': True
        }
        response = self.client.post(self.register_url, data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn('token', response.data)
        self.assertEqual(response.data['user']['email'], 'john@example.com')
        
        # Verify user and profile created
        user = User.objects.get(email='john@example.com')
        self.assertTrue(hasattr(user, 'profile'))
        self.assertEqual(user.profile.user_type, 'customer')
    
    def test_owner_registration_creates_office(self):
        """Test owner registration creates office"""
        data = {
            'first_name': 'Jane',
            'last_name': 'Smith',
            'email': 'jane@example.com',
            'password': 'SecurePass123!',
            'password_confirm': 'SecurePass123!',
            'user_type': 'owner',
            'office_name': 'Jane\'s Rentals',
            'office_location': 'Downtown',
            'accept_terms': True
        }
        response = self.client.post(self.register_url, data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        
        user = User.objects.get(email='jane@example.com')
        self.assertTrue(user.offices.exists())
        self.assertEqual(user.offices.first().name, "Jane's Rentals")
    
    def test_duplicate_email_rejected(self):
        """Test duplicate email registration fails"""
        User.objects.create_user(
            username='existing',
            email='existing@example.com',
            password='password123'
        )
        
        data = {
            'first_name': 'New',
            'last_name': 'User',
            'email': 'existing@example.com',
            'password': 'SecurePass123!',
            'password_confirm': 'SecurePass123!',
            'user_type': 'customer',
            'accept_terms': True
        }
        response = self.client.post(self.register_url, data)
        
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email', response.data)
    
    def test_login_success(self):
        """Test successful login returns token"""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        Profile.objects.create(user=user, user_type='customer')
        
        response = self.client.post(self.login_url, {
            'email': 'test@example.com',
            'password': 'testpass123'
        })
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('token', response.data)
    
    def test_login_wrong_password(self):
        """Test login with wrong password fails"""
        User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        
        response = self.client.post(self.login_url, {
            'email': 'test@example.com',
            'password': 'wrongpassword'
        })
        
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class CarTests(APITestCase):
    """Test car listing and management"""
    
    def setUp(self):
        # Create owner user
        self.owner = User.objects.create_user(
            username='owner',
            email='owner@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.owner, user_type='owner')
        
        # Create office
        self.office = Office.objects.create(
            name='Test Office',
            location='Test Location',
            owner=self.owner,
            is_approved=True
        )
        
        # Create cars
        self.car1 = Car.objects.create(
            office=self.office,
            brand='Toyota',
            model='Camry',
            year=2022,
            price_per_day=Decimal('50.00'),
            location='Downtown',
            fuel_type='Petrol',
            transmission_type='Automatic',
            is_available=True
        )
        
        self.car2 = Car.objects.create(
            office=self.office,
            brand='Tesla',
            model='Model 3',
            year=2023,
            price_per_day=Decimal('100.00'),
            location='Airport',
            fuel_type='Electric',
            transmission_type='Automatic',
            is_available=True
        )
        
        # Get token for owner
        self.token = Token.objects.create(user=self.owner)
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token.key}')
    
    def test_list_cars(self):
        """Test car listing returns available cars"""
        self.client.credentials()  # Remove auth for public endpoint
        response = self.client.get('/api/cars/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 2)
    
    def test_filter_cars_by_brand(self):
        """Test filtering cars by brand"""
        self.client.credentials()
        response = self.client.get('/api/cars/', {'brand': 'Toyota'})
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['brand'], 'Toyota')
    
    def test_filter_cars_by_fuel_type(self):
        """Test filtering cars by fuel type"""
        self.client.credentials()
        response = self.client.get('/api/cars/', {'fuel_type': 'Electric'})
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['brand'], 'Tesla')
    
    def test_car_detail(self):
        """Test car detail endpoint"""
        self.client.credentials()
        response = self.client.get(f'/api/cars/{self.car1.id}/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['brand'], 'Toyota')
        self.assertEqual(response.data['model'], 'Camry')
    
    def test_owner_can_create_car(self):
        """Test owner can create new car"""
        data = {
            'brand': 'Honda',
            'model': 'Civic',
            'year': 2021,
            'price_per_day': '45.00',
            'location': 'Mall',
            'fuel_type': 'Petrol',
            'transmission_type': 'Manual',
            'body_type': 'Sedan',
            'number_of_seats': 5,
            'is_available': True
        }
        response = self.client.post('/api/cars/', data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Car.objects.count(), 3)


class BookingTests(APITestCase):
    """Test booking creation and management"""
    
    def setUp(self):
        # Create customer
        self.customer = User.objects.create_user(
            username='customer',
            email='customer@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.customer, user_type='customer')
        
        # Create owner and office
        self.owner = User.objects.create_user(
            username='owner',
            email='owner@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.owner, user_type='owner')
        
        self.office = Office.objects.create(
            name='Test Office',
            location='Test Location',
            owner=self.owner,
            is_approved=True
        )
        
        # Create car
        self.car = Car.objects.create(
            office=self.office,
            brand='Toyota',
            model='Camry',
            year=2022,
            price_per_day=Decimal('50.00'),
            daily_rate=Decimal('50.00'),
            location='Downtown',
            is_available=True
        )
        
        # Auth as customer
        self.token = Token.objects.create(user=self.customer)
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token.key}')
    
    def test_create_booking(self):
        """Test creating a new booking"""
        start_date = date.today() + timedelta(days=7)
        end_date = start_date + timedelta(days=3)
        
        data = {
            'car_id': self.car.id,
            'customer_name': 'John Doe',
            'customer_email': 'john@example.com',
            'customer_phone': '1234567890',
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat()
        }
        response = self.client.post('/api/bookings/', data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Booking.objects.count(), 1)
        
        booking = Booking.objects.first()
        self.assertEqual(booking.user, self.customer)
        self.assertEqual(booking.car, self.car)
        self.assertEqual(booking.num_days, 4)
    
    def test_cannot_book_overlapping_dates(self):
        """Test overlapping booking is rejected"""
        start_date = date.today() + timedelta(days=7)
        end_date = start_date + timedelta(days=3)
        
        # Create first booking
        Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='First',
            customer_email='first@example.com',
            customer_phone='1111111111',
            start_date=start_date,
            end_date=end_date,
            status='confirmed'
        )
        
        # Try overlapping booking
        data = {
            'car_id': self.car.id,
            'customer_name': 'Second',
            'customer_email': 'second@example.com',
            'customer_phone': '2222222222',
            'start_date': (start_date + timedelta(days=1)).isoformat(),
            'end_date': (end_date + timedelta(days=1)).isoformat()
        }
        response = self.client.post('/api/bookings/', data)
        
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('dates', str(response.data))
    
    def test_cancel_booking(self):
        """Test booking cancellation"""
        start_date = date.today() + timedelta(days=10)
        end_date = start_date + timedelta(days=3)
        
        booking = Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='Test',
            customer_email='test@example.com',
            customer_phone='1234567890',
            start_date=start_date,
            end_date=end_date,
            status='confirmed'
        )
        
        response = self.client.put(f'/api/bookings/{booking.id}/cancel/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        booking.refresh_from_db()
        self.assertEqual(booking.status, 'cancelled')


class ReviewTests(APITestCase):
    """Test review submission - verified only"""
    
    def setUp(self):
        # Create customer
        self.customer = User.objects.create_user(
            username='customer',
            email='customer@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.customer, user_type='customer')
        
        # Create owner and office
        self.owner = User.objects.create_user(
            username='owner',
            email='owner@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.owner, user_type='owner')
        
        self.office = Office.objects.create(
            name='Test Office',
            location='Test Location',
            owner=self.owner,
            is_approved=True
        )
        
        # Create car
        self.car = Car.objects.create(
            office=self.office,
            brand='Toyota',
            model='Camry',
            year=2022,
            price_per_day=Decimal('50.00'),
            location='Downtown',
            is_available=True
        )
        
        # Create completed booking
        self.booking = Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='Test',
            customer_email='test@example.com',
            customer_phone='1234567890',
            start_date=date.today() - timedelta(days=5),
            end_date=date.today() - timedelta(days=2),
            status='completed'
        )
        
        # Auth as customer
        self.token = Token.objects.create(user=self.customer)
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token.key}')
    
    def test_can_review_completed_booking(self):
        """Test customer can review completed booking"""
        data = {
            'booking_id': self.booking.id,
            'rating': 5,
            'title': 'Great experience!',
            'comment': 'The car was in perfect condition.'
        }
        response = self.client.post('/api/reviews/', data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Review.objects.count(), 1)
    
    def test_cannot_review_pending_booking(self):
        """Test cannot review pending booking"""
        pending_booking = Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='Test',
            customer_email='test@example.com',
            customer_phone='1234567890',
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=8),
            status='pending'
        )
        
        data = {
            'booking_id': pending_booking.id,
            'rating': 5,
            'title': 'Test',
            'comment': 'Test'
        }
        response = self.client.post('/api/reviews/', data)
        
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
    
    def test_cannot_review_twice(self):
        """Test cannot submit duplicate review"""
        # First review
        Review.objects.create(
            car=self.car,
            user=self.customer,
            booking=self.booking,
            rating=4,
            comment='Good'
        )
        
        # Try second review
        data = {
            'booking_id': self.booking.id,
            'rating': 5,
            'comment': 'Great'
        }
        response = self.client.post('/api/reviews/', data)
        
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class FavoriteTests(APITestCase):
    """Test favorites functionality"""
    
    def setUp(self):
        self.customer = User.objects.create_user(
            username='customer',
            email='customer@example.com',
            password='password123'
        )
        Profile.objects.create(user=self.customer, user_type='customer')
        
        self.owner = User.objects.create_user(
            username='owner',
            email='owner@example.com',
            password='password123'
        )
        self.office = Office.objects.create(
            name='Test',
            location='Test',
            owner=self.owner,
            is_approved=True
        )
        
        self.car = Car.objects.create(
            office=self.office,
            brand='Toyota',
            model='Camry',
            year=2022,
            price_per_day=Decimal('50.00'),
            location='Downtown',
            is_available=True
        )
        
        self.token = Token.objects.create(user=self.customer)
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.token.key}')
    
    def test_add_favorite(self):
        """Test adding car to favorites"""
        response = self.client.post('/api/favorites/', {'car_id': self.car.id})
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(Favorite.objects.filter(user=self.customer, car=self.car).exists())
    
    def test_remove_favorite(self):
        """Test removing car from favorites"""
        Favorite.objects.create(user=self.customer, car=self.car)
        
        response = self.client.delete(f'/api/favorites/car/{self.car.id}/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(Favorite.objects.filter(user=self.customer, car=self.car).exists())


class PricingServiceTests(TestCase):
    """Test pricing calculations"""
    
    def setUp(self):
        self.owner = User.objects.create_user('owner', 'owner@test.com', 'pass')
        self.office = Office.objects.create(name='Test', location='Test', owner=self.owner, is_approved=True)
        self.car = Car.objects.create(
            office=self.office,
            brand='Test',
            model='Car',
            year=2022,
            price_per_day=Decimal('50.00'),
            location='Test',
            is_available=True
        )
    
    def test_rental_cost_calculation(self):
        """Test basic rental cost calculation"""
        from .services.pricing import calculate_rental_cost
        
        start_date = date.today() + timedelta(days=1)
        end_date = start_date + timedelta(days=2)  # 3 days total
        
        result = calculate_rental_cost(self.car, start_date, end_date)
        
        self.assertEqual(result['num_days'], 3)
        self.assertEqual(result['daily_rate'], 50.0)
        self.assertEqual(result['subtotal'], 150.0)
        self.assertEqual(result['total'], 150.0)
    
    def test_discount_application(self):
        """Test discount code application"""
        from .services.pricing import calculate_rental_cost
        
        # Create discount
        Discount.objects.create(
            code='TEST20',
            name='20% Off',
            discount_type='percentage',
            value=Decimal('20'),
            start_date=date.today() - timedelta(days=1),
            end_date=date.today() + timedelta(days=30),
            min_rental_days=1
        )
        
        start_date = date.today() + timedelta(days=1)
        end_date = start_date + timedelta(days=2)
        
        result = calculate_rental_cost(self.car, start_date, end_date, 'TEST20')
        
        self.assertEqual(result['discount']['code'], 'TEST20')
        self.assertEqual(result['discount_amount'], 30.0)  # 20% of 150
        self.assertEqual(result['total'], 120.0)


class AvailabilityServiceTests(TestCase):
    """Test availability checking"""
    
    def setUp(self):
        self.owner = User.objects.create_user('owner', 'owner@test.com', 'pass')
        self.customer = User.objects.create_user('customer', 'customer@test.com', 'pass')
        self.office = Office.objects.create(name='Test', location='Test', owner=self.owner, is_approved=True)
        self.car = Car.objects.create(
            office=self.office,
            brand='Test',
            model='Car',
            year=2022,
            price_per_day=Decimal('50.00'),
            location='Test',
            is_available=True
        )
    
    def test_car_available_no_bookings(self):
        """Test car with no bookings is available"""
        from .services.availability import is_car_available
        
        start_date = date.today() + timedelta(days=5)
        end_date = start_date + timedelta(days=3)
        
        self.assertTrue(is_car_available(self.car.id, start_date, end_date))
    
    def test_car_unavailable_with_overlap(self):
        """Test car with overlapping booking is unavailable"""
        from .services.availability import is_car_available
        
        # Existing booking
        Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='Test',
            customer_email='test@test.com',
            customer_phone='123',
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=10),
            status='confirmed'
        )
        
        # Try overlapping dates
        start_date = date.today() + timedelta(days=7)  # Overlaps
        end_date = start_date + timedelta(days=3)
        
        self.assertFalse(is_car_available(self.car.id, start_date, end_date))
    
    def test_car_available_non_overlapping(self):
        """Test car available for non-overlapping dates"""
        from .services.availability import is_car_available
        
        # Existing booking
        Booking.objects.create(
            car=self.car,
            user=self.customer,
            customer_name='Test',
            customer_email='test@test.com',
            customer_phone='123',
            start_date=date.today() + timedelta(days=5),
            end_date=date.today() + timedelta(days=10),
            status='confirmed'
        )
        
        # Non-overlapping dates
        start_date = date.today() + timedelta(days=15)
        end_date = start_date + timedelta(days=3)
        
        self.assertTrue(is_car_available(self.car.id, start_date, end_date))
