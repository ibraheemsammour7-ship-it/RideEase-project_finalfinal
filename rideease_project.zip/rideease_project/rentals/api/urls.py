from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    # Auth
    register_view, login_view, logout_view,
    forgot_password_view, reset_password_view, verify_email_view, delete_account_view,
    # Profile
    ProfileView, change_password_view,
    # Office
    OfficeViewSet, OfficeRatingView,
    # Car
    CarViewSet,
    # Booking
    BookingViewSet,
    # Payment
    process_payment, payment_history, get_receipt,
    # Review
    ReviewViewSet,
    # Favorites
    FavoriteViewSet,
    # Recommendations
    get_recommendations,
    # Notifications
    NotificationViewSet,
    # Support
    SupportTicketViewSet, FAQViewSet,
    # Map
    map_cars,
    # Admin
    admin_analytics, AdminUserViewSet, AdminCarViewSet, AdminReviewViewSet, AdminInsuranceViewSet
)

# Create router
router = DefaultRouter()
router.register(r'offices', OfficeViewSet, basename='office')
router.register(r'cars', CarViewSet, basename='car')
router.register(r'bookings', BookingViewSet, basename='booking')
router.register(r'reviews', ReviewViewSet, basename='review')
router.register(r'favorites', FavoriteViewSet, basename='favorite')
router.register(r'notifications', NotificationViewSet, basename='notification')
router.register(r'support/tickets', SupportTicketViewSet, basename='support-ticket')
router.register(r'faq', FAQViewSet, basename='faq')

# Admin routers
router.register(r'admin/users', AdminUserViewSet, basename='admin-user')
router.register(r'admin/cars', AdminCarViewSet, basename='admin-car')
router.register(r'admin/reviews', AdminReviewViewSet, basename='admin-review')
router.register(r'admin/insurance', AdminInsuranceViewSet, basename='admin-insurance')

urlpatterns = [
    # Include router URLs
    path('', include(router.urls)),
    
    # Auth endpoints
    path('auth/register/', register_view, name='api-register'),
    path('auth/login/', login_view, name='api-login'),
    path('auth/logout/', logout_view, name='api-logout'),
    path('auth/forgot-password/', forgot_password_view, name='api-forgot-password'),
    path('auth/reset-password/', reset_password_view, name='api-reset-password'),
    path('auth/verify-email/', verify_email_view, name='api-verify-email'),
    path('auth/delete-account/', delete_account_view, name='api-delete-account'),
    
    # Profile endpoints
    path('users/me/', ProfileView.as_view(), name='api-profile'),
    path('users/me/change-password/', change_password_view, name='api-change-password'),
    
    # Office rating
    path('offices/<int:office_id>/rate/', OfficeRatingView.as_view(), name='api-rate-office'),
    
    # Payment endpoints
    path('payments/', process_payment, name='api-process-payment'),
    path('payments/history/', payment_history, name='api-payment-history'),
    path('payments/<int:payment_id>/receipt/', get_receipt, name='api-get-receipt'),
    
    # Recommendations
    path('recommendations/', get_recommendations, name='api-recommendations'),
    
    # Map
    path('map/cars/', map_cars, name='api-map-cars'),
    
    # Admin analytics
    path('admin/analytics/', admin_analytics, name='api-admin-analytics'),
]
