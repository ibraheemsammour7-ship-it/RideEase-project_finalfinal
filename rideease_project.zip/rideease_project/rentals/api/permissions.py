from rest_framework import permissions


class IsOwnerOrAdmin(permissions.BasePermission):
    """Allow access only to object owner or admin users."""
    
    def has_object_permission(self, request, view, obj):
        if request.user.is_staff:
            return True
        
        # Check various owner fields
        if hasattr(obj, 'user'):
            return obj.user == request.user
        if hasattr(obj, 'owner'):
            return obj.owner == request.user
        if hasattr(obj, 'office'):
            return obj.office.owner == request.user
        
        return False


class IsRenter(permissions.BasePermission):
    """Allow access only to customers/renters."""
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if hasattr(request.user, 'profile'):
            return request.user.profile.user_type == 'customer'
        return False


class IsSupplier(permissions.BasePermission):
    """Allow access only to suppliers/office owners."""
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if hasattr(request.user, 'profile'):
            return request.user.profile.user_type == 'owner'
        return False


class IsAdmin(permissions.BasePermission):
    """Allow access only to admins."""
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if request.user.is_staff:
            return True
        if hasattr(request.user, 'profile'):
            return request.user.profile.user_type == 'admin'
        return False


class IsRenterOrSupplier(permissions.BasePermission):
    """Allow access to both renters and suppliers."""
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        if hasattr(request.user, 'profile'):
            return request.user.profile.user_type in ['customer', 'owner']
        return False


class IsOwnerOfCarOrAdmin(permissions.BasePermission):
    """Allow access only to car owner (via office) or admin."""
    
    def has_object_permission(self, request, view, obj):
        if request.user.is_staff:
            return True
        
        # For Car model
        if hasattr(obj, 'office'):
            return obj.office.owner == request.user
        
        return False


class IsBookingParticipant(permissions.BasePermission):
    """Allow access to booking renter, supplier, or admin."""
    
    def has_object_permission(self, request, view, obj):
        if request.user.is_staff:
            return True
        
        # For Booking model
        if hasattr(obj, 'user') and obj.user == request.user:
            return True
        if hasattr(obj, 'supplier') and obj.supplier == request.user:
            return True
        
        return False


class ReadOnly(permissions.BasePermission):
    """Allow only GET, HEAD, OPTIONS requests."""
    
    def has_permission(self, request, view):
        return request.method in permissions.SAFE_METHODS
