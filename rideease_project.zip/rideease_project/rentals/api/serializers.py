from rest_framework import serializers
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.utils import timezone

from ..models import (
    Profile, TermsAcceptance,
    Office, OfficeRating,
    Car, CarImage, CarInsuranceDoc,
    Booking, RentalAgreement, BookingExtension,
    Payment, Receipt,
    Review, Favorite,
    Notification, SupportTicket, FAQItem,
    DamageReport, DamageReportImage,
    Discount
)


# =============================================
# USER & AUTH SERIALIZERS
# =============================================

class ProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.EmailField(source='user.email', read_only=True)
    first_name = serializers.CharField(source='user.first_name')
    last_name = serializers.CharField(source='user.last_name')
    
    class Meta:
        model = Profile
        fields = [
            'username', 'email', 'first_name', 'last_name',
            'user_type', 'phone', 'address', 'email_verified',
            'preferred_language', 'dark_mode', 'created_at'
        ]
        read_only_fields = ['username', 'email', 'email_verified', 'user_type', 'created_at']
    
    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        if user_data:
            instance.user.first_name = user_data.get('first_name', instance.user.first_name)
            instance.user.last_name = user_data.get('last_name', instance.user.last_name)
            instance.user.save()
        return super().update(instance, validated_data)


class UserRegistrationSerializer(serializers.Serializer):
    first_name = serializers.CharField(max_length=30)
    last_name = serializers.CharField(max_length=30)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    user_type = serializers.ChoiceField(choices=['customer', 'owner'])
    office_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    office_location = serializers.CharField(max_length=255, required=False, allow_blank=True)
    accept_terms = serializers.BooleanField()
    
    def validate_email(self, value):
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        return value
    
    def validate(self, data):
        if data['password'] != data['password_confirm']:
            raise serializers.ValidationError({"password_confirm": "Passwords do not match."})
        if not data.get('accept_terms'):
            raise serializers.ValidationError({"accept_terms": "You must accept the terms and conditions."})
        if data['user_type'] == 'owner':
            if not data.get('office_name'):
                raise serializers.ValidationError({"office_name": "Office name is required for owners."})
        return data
    
    def create(self, validated_data):
        username = f"{validated_data['first_name'].lower()}_{validated_data['last_name'].lower()}"
        # Ensure unique username
        base_username = username
        counter = 1
        while User.objects.filter(username=username).exists():
            username = f"{base_username}{counter}"
            counter += 1
        
        user = User.objects.create_user(
            username=username,
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name']
        )
        
        profile = Profile.objects.create(
            user=user,
            user_type=validated_data['user_type']
        )
        
        # Create terms acceptance record
        TermsAcceptance.objects.create(
            user=user,
            terms_version='1.0',
            ip_address=self.context.get('ip_address')
        )
        
        # Create office if owner
        if validated_data['user_type'] == 'owner':
            Office.objects.create(
                name=validated_data['office_name'],
                location=validated_data.get('office_location', ''),
                owner=user
            )
        
        return user


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    token = serializers.CharField()
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    
    def validate(self, data):
        if data['password'] != data['password_confirm']:
            raise serializers.ValidationError({"password_confirm": "Passwords do not match."})
        return data


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])
    new_password_confirm = serializers.CharField(write_only=True)
    
    def validate(self, data):
        if data['new_password'] != data['new_password_confirm']:
            raise serializers.ValidationError({"new_password_confirm": "Passwords do not match."})
        return data


# =============================================
# OFFICE SERIALIZERS
# =============================================

class OfficeListSerializer(serializers.ModelSerializer):
    owner_name = serializers.CharField(source='owner.get_full_name', read_only=True)
    car_count = serializers.SerializerMethodField()
    average_rating = serializers.FloatField(source='rating', read_only=True)
    
    class Meta:
        model = Office
        fields = ['id', 'name', 'location', 'lat', 'lng', 'owner_name', 'average_rating', 'car_count']
    
    def get_car_count(self, obj):
        return obj.cars.filter(is_available=True).count()


class OfficeDetailSerializer(serializers.ModelSerializer):
    owner_name = serializers.CharField(source='owner.get_full_name', read_only=True)
    cars = serializers.SerializerMethodField()
    ratings = serializers.SerializerMethodField()
    
    class Meta:
        model = Office
        fields = ['id', 'name', 'location', 'lat', 'lng', 'owner_name', 'rating', 'cars', 'ratings', 'created_at']
    
    def get_cars(self, obj):
        cars = obj.cars.filter(is_available=True)[:10]
        return CarListSerializer(cars, many=True).data
    
    def get_ratings(self, obj):
        ratings = obj.ratings.all()[:5]
        return OfficeRatingSerializer(ratings, many=True).data


class OfficeRatingSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    
    class Meta:
        model = OfficeRating
        fields = ['id', 'user_name', 'rating', 'comment', 'created_at']


class CreateOfficeRatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = OfficeRating
        fields = ['rating', 'comment']
    
    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


# =============================================
# CAR SERIALIZERS
# =============================================

class CarImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = CarImage
        fields = ['id', 'image', 'sort_order']


class CarListSerializer(serializers.ModelSerializer):
    office_name = serializers.CharField(source='office.name', read_only=True)
    primary_image = serializers.SerializerMethodField()
    
    class Meta:
        model = Car
        fields = [
            'id', 'brand', 'model', 'year', 'price_per_day',
            'location', 'fuel_type', 'transmission_type', 'body_type',
            'number_of_seats', 'color', 'avg_rating', 'total_reviews',
            'is_available', 'office_name', 'primary_image'
        ]
    
    def get_primary_image(self, obj):
        if obj.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        first_image = obj.images.first()
        if first_image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(first_image.image.url)
            return first_image.image.url
        return None


class CarDetailSerializer(serializers.ModelSerializer):
    office = OfficeListSerializer(read_only=True)
    images = CarImageSerializer(many=True, read_only=True)
    reviews = serializers.SerializerMethodField()
    is_favorited = serializers.SerializerMethodField()
    
    class Meta:
        model = Car
        fields = [
            'id', 'brand', 'model', 'year', 'price_per_day', 'daily_rate',
            'location', 'lat', 'lng', 'fuel_type', 'transmission_type',
            'body_type', 'number_of_seats', 'engine_size', 'battery_range',
            'color', 'shipping_available', 'is_available',
            'avg_rating', 'total_reviews', 'office', 'images', 'image',
            'reviews', 'is_favorited', 'created_at'
        ]
    
    def get_reviews(self, obj):
        reviews = obj.reviews.filter(status='approved')[:5]
        return ReviewSerializer(reviews, many=True).data
    
    def get_is_favorited(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return Favorite.objects.filter(user=request.user, car=obj).exists()
        return False


class CarCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Car
        fields = [
            'brand', 'model', 'year', 'price_per_day',
            'location', 'lat', 'lng', 'fuel_type', 'transmission_type',
            'body_type', 'number_of_seats', 'engine_size', 'battery_range',
            'color', 'shipping_available', 'is_available', 'image'
        ]
    
    def create(self, validated_data):
        user = self.context['request'].user
        office = user.offices.first()
        if not office:
            raise serializers.ValidationError("You must have an office to add cars.")
        validated_data['office'] = office
        validated_data['daily_rate'] = validated_data.get('price_per_day', 0)
        return super().create(validated_data)


class CarInsuranceDocSerializer(serializers.ModelSerializer):
    class Meta:
        model = CarInsuranceDoc
        fields = ['id', 'document', 'status', 'uploaded_at', 'reviewed_at', 'rejection_reason']
        read_only_fields = ['status', 'reviewed_at', 'rejection_reason']


# =============================================
# BOOKING SERIALIZERS
# =============================================

class BookingListSerializer(serializers.ModelSerializer):
    car = CarListSerializer(read_only=True)
    can_review = serializers.SerializerMethodField()
    can_cancel = serializers.SerializerMethodField()
    
    class Meta:
        model = Booking
        fields = [
            'id', 'booking_ref', 'car', 'customer_name',
            'start_date', 'end_date', 'status',
            'num_days', 'total_amount', 'created_at',
            'can_review', 'can_cancel'
        ]
    
    def get_can_review(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return (
            obj.status == 'completed' and 
            obj.user == request.user and
            not hasattr(obj, 'review')
        )
    
    def get_can_cancel(self, obj):
        if obj.status not in ['pending', 'confirmed', 'approved']:
            return False
        return obj.start_date > timezone.now().date()


class BookingDetailSerializer(serializers.ModelSerializer):
    car = CarDetailSerializer(read_only=True)
    agreement = serializers.SerializerMethodField()
    damage_reports = serializers.SerializerMethodField()
    payments = serializers.SerializerMethodField()
    
    class Meta:
        model = Booking
        fields = [
            'id', 'booking_ref', 'car', 'user', 'supplier',
            'customer_name', 'customer_email', 'customer_phone',
            'start_date', 'end_date', 'actual_return_date', 'status',
            'daily_rate', 'num_days', 'subtotal', 'discount_amount',
            'late_fee', 'total_amount', 'created_at', 'updated_at',
            'agreement', 'damage_reports', 'payments'
        ]
    
    def get_agreement(self, obj):
        if hasattr(obj, 'agreement'):
            return RentalAgreementSerializer(obj.agreement).data
        return None
    
    def get_damage_reports(self, obj):
        return DamageReportSerializer(obj.damage_reports.all(), many=True).data
    
    def get_payments(self, obj):
        return PaymentSerializer(obj.payments.all(), many=True).data


class CreateBookingSerializer(serializers.ModelSerializer):
    car_id = serializers.IntegerField(write_only=True)
    discount_code = serializers.CharField(required=False, allow_blank=True)
    
    class Meta:
        model = Booking
        fields = [
            'car_id', 'customer_name', 'customer_email', 'customer_phone',
            'start_date', 'end_date', 'discount_code'
        ]
    
    def validate(self, data):
        car_id = data.get('car_id')
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        
        if start_date >= end_date:
            raise serializers.ValidationError({"end_date": "End date must be after start date."})
        
        if start_date < timezone.now().date():
            raise serializers.ValidationError({"start_date": "Start date cannot be in the past."})
        
        try:
            car = Car.objects.get(id=car_id)
        except Car.DoesNotExist:
            raise serializers.ValidationError({"car_id": "Car not found."})
        
        if not car.is_available_for_dates(start_date, end_date):
            raise serializers.ValidationError({"dates": "Car is not available for these dates."})
        
        data['car'] = car
        return data
    
    def create(self, validated_data):
        car = validated_data.pop('car')
        discount_code = validated_data.pop('discount_code', None)
        
        booking = Booking(
            car=car,
            user=self.context['request'].user,
            supplier=car.office.owner,
            **validated_data
        )
        
        # Calculate costs
        booking.calculate_cost()
        
        # Apply discount if valid
        if discount_code:
            try:
                discount = Discount.objects.get(code=discount_code)
                if discount.is_valid():
                    booking.discount_amount = discount.calculate_discount(booking.subtotal)
                    booking.total_amount = booking.subtotal - booking.discount_amount
                    discount.current_uses += 1
                    discount.save()
            except Discount.DoesNotExist:
                pass
        
        booking.save()
        
        # Create rental agreement
        RentalAgreement.objects.create(
            booking=booking,
            terms_snapshot={
                'fuel_policy': 'Return with full tank',
                'late_fee_policy': '150% of daily rate per day',
                'cancellation_policy': '7+ days: 100% refund, 3-7 days: 50% refund, <3 days: no refund'
            }
        )
        
        return booking


class BookingExtensionSerializer(serializers.ModelSerializer):
    class Meta:
        model = BookingExtension
        fields = [
            'id', 'booking', 'original_end_date', 'requested_end_date',
            'extra_days', 'extra_amount', 'status', 'decided_at'
        ]
        read_only_fields = ['booking', 'original_end_date', 'extra_days', 'extra_amount', 'status', 'decided_at']


class CreateExtensionSerializer(serializers.Serializer):
    requested_end_date = serializers.DateField()
    
    def validate_requested_end_date(self, value):
        booking = self.context['booking']
        if value <= booking.end_date:
            raise serializers.ValidationError("New end date must be after current end date.")
        return value


# =============================================
# RENTAL AGREEMENT SERIALIZERS
# =============================================

class RentalAgreementSerializer(serializers.ModelSerializer):
    is_fully_signed = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = RentalAgreement
        fields = [
            'id', 'booking', 'agreement_pdf', 'terms_snapshot',
            'renter_signed_at', 'supplier_signed_at', 'is_fully_signed'
        ]


# =============================================
# PAYMENT SERIALIZERS
# =============================================

class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'id', 'booking', 'payment_type', 'amount', 'currency',
            'provider', 'status', 'created_at'
        ]


class CreatePaymentSerializer(serializers.Serializer):
    booking_id = serializers.IntegerField()
    payment_method = serializers.ChoiceField(choices=['card', 'cash'])
    
    # Card details (for simulation)
    card_number = serializers.CharField(required=False, max_length=16)
    card_expiry = serializers.CharField(required=False, max_length=5)
    card_cvv = serializers.CharField(required=False, max_length=4)
    
    def validate(self, data):
        if data['payment_method'] == 'card':
            if not all([data.get('card_number'), data.get('card_expiry'), data.get('card_cvv')]):
                raise serializers.ValidationError("Card details are required for card payment.")
        return data


class ReceiptSerializer(serializers.ModelSerializer):
    payment = PaymentSerializer(read_only=True)
    
    class Meta:
        model = Receipt
        fields = ['id', 'receipt_number', 'payment', 'receipt_pdf', 'created_at']


# =============================================
# REVIEW SERIALIZERS
# =============================================

class ReviewSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    
    class Meta:
        model = Review
        fields = ['id', 'user_name', 'rating', 'title', 'comment', 'status', 'created_at']


class CreateReviewSerializer(serializers.ModelSerializer):
    booking_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = Review
        fields = ['booking_id', 'rating', 'title', 'comment']
    
    def validate(self, data):
        booking_id = data.get('booking_id')
        user = self.context['request'].user
        
        try:
            booking = Booking.objects.get(id=booking_id)
        except Booking.DoesNotExist:
            raise serializers.ValidationError({"booking_id": "Booking not found."})
        
        if booking.user != user:
            raise serializers.ValidationError({"booking_id": "You can only review your own bookings."})
        
        if booking.status != 'completed':
            raise serializers.ValidationError({"booking_id": "You can only review completed bookings."})
        
        if hasattr(booking, 'review'):
            raise serializers.ValidationError({"booking_id": "You have already reviewed this booking."})
        
        data['booking'] = booking
        data['car'] = booking.car
        return data
    
    def create(self, validated_data):
        booking = validated_data.pop('booking')
        car = validated_data.pop('car')
        validated_data.pop('booking_id')
        
        review = Review.objects.create(
            booking=booking,
            car=car,
            user=self.context['request'].user,
            **validated_data
        )
        return review


# =============================================
# FAVORITE SERIALIZERS
# =============================================

class FavoriteSerializer(serializers.ModelSerializer):
    car = CarListSerializer(read_only=True)
    
    class Meta:
        model = Favorite
        fields = ['id', 'car', 'created_at']


# =============================================
# DAMAGE REPORT SERIALIZERS
# =============================================

class DamageReportImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = DamageReportImage
        fields = ['id', 'image', 'caption']


class DamageReportSerializer(serializers.ModelSerializer):
    images = DamageReportImageSerializer(many=True, read_only=True)
    reporter_name = serializers.CharField(source='reporter.get_full_name', read_only=True)
    
    class Meta:
        model = DamageReport
        fields = [
            'id', 'report_type', 'reported_by', 'reporter_name',
            'notes', 'fuel_level', 'mileage', 'has_damage',
            'damage_description', 'estimated_repair_cost',
            'images', 'created_at'
        ]


class CreateDamageReportSerializer(serializers.ModelSerializer):
    images = serializers.ListField(
        child=serializers.ImageField(),
        required=False,
        write_only=True
    )
    
    class Meta:
        model = DamageReport
        fields = [
            'report_type', 'notes', 'fuel_level', 'mileage',
            'has_damage', 'damage_description', 'estimated_repair_cost',
            'images'
        ]
    
    def create(self, validated_data):
        images = validated_data.pop('images', [])
        booking = self.context['booking']
        user = self.context['request'].user
        
        # Determine reported_by based on user role
        if user == booking.user:
            reported_by = 'renter'
        else:
            reported_by = 'supplier'
        
        report = DamageReport.objects.create(
            booking=booking,
            reporter=user,
            reported_by=reported_by,
            **validated_data
        )
        
        for image in images:
            DamageReportImage.objects.create(damage_report=report, image=image)
        
        return report


# =============================================
# NOTIFICATION SERIALIZERS
# =============================================

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = [
            'id', 'notification_type', 'channel', 'title', 'message',
            'data', 'is_read', 'read_at', 'sent_at', 'created_at'
        ]


# =============================================
# SUPPORT SERIALIZERS
# =============================================

class SupportTicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportTicket
        fields = [
            'id', 'ticket_number', 'subject', 'message', 'category',
            'priority', 'status', 'created_at'
        ]
        read_only_fields = ['ticket_number', 'status']


class CreateSupportTicketSerializer(serializers.ModelSerializer):
    booking_id = serializers.IntegerField(required=False)
    
    class Meta:
        model = SupportTicket
        fields = ['subject', 'message', 'category', 'priority', 'booking_id']
    
    def create(self, validated_data):
        booking_id = validated_data.pop('booking_id', None)
        booking = None
        if booking_id:
            try:
                booking = Booking.objects.get(id=booking_id)
            except Booking.DoesNotExist:
                pass
        
        ticket = SupportTicket.objects.create(
            user=self.context['request'].user,
            booking=booking,
            **validated_data
        )
        return ticket


class FAQItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQItem
        fields = ['id', 'question', 'answer', 'category', 'tags']


# =============================================
# MAP SERIALIZERS
# =============================================

class CarMapSerializer(serializers.ModelSerializer):
    """Lightweight serializer for map markers"""
    class Meta:
        model = Car
        fields = ['id', 'brand', 'model', 'lat', 'lng', 'price_per_day', 'is_available']


# =============================================
# ADMIN/ANALYTICS SERIALIZERS
# =============================================

class AnalyticsSerializer(serializers.Serializer):
    total_users = serializers.IntegerField()
    total_cars = serializers.IntegerField()
    total_bookings = serializers.IntegerField()
    total_revenue = serializers.DecimalField(max_digits=12, decimal_places=2)
    active_bookings = serializers.IntegerField()
    pending_reviews = serializers.IntegerField()
    pending_insurance = serializers.IntegerField()
    popular_cars = serializers.ListField()
    recent_bookings = serializers.ListField()


class AdminUserSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer(read_only=True)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active', 'date_joined', 'profile']
