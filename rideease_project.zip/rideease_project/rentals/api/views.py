from rest_framework import viewsets, generics, status, filters
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from django.db.models import Sum, Count, Q
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
import uuid

from ..models import (
    Profile, TermsAcceptance, PasswordResetToken,
    Office, OfficeRating,
    Car, CarImage, CarInsuranceDoc,
    Booking, RentalAgreement, BookingExtension,
    Payment, Receipt,
    Review, Favorite, Notification,
    SupportTicket, FAQItem,
    DamageReport
)

from .serializers import (
    ProfileSerializer, UserRegistrationSerializer, LoginSerializer,
    PasswordResetRequestSerializer, PasswordResetConfirmSerializer, ChangePasswordSerializer,
    OfficeListSerializer, OfficeDetailSerializer, OfficeRatingSerializer, CreateOfficeRatingSerializer,
    CarListSerializer, CarDetailSerializer, CarCreateUpdateSerializer, CarImageSerializer, CarInsuranceDocSerializer,
    BookingListSerializer, BookingDetailSerializer, CreateBookingSerializer, BookingExtensionSerializer, CreateExtensionSerializer,
    RentalAgreementSerializer,
    PaymentSerializer, CreatePaymentSerializer, ReceiptSerializer,
    ReviewSerializer, CreateReviewSerializer,
    FavoriteSerializer,
    DamageReportSerializer, CreateDamageReportSerializer,
    NotificationSerializer,
    SupportTicketSerializer, CreateSupportTicketSerializer, FAQItemSerializer,
    CarMapSerializer, AnalyticsSerializer, AdminUserSerializer
)

from .permissions import IsOwnerOrAdmin, IsRenter, IsSupplier, IsAdmin, IsBookingParticipant, IsOwnerOfCarOrAdmin


# =============================================
# AUTH VIEWS
# =============================================

@api_view(['POST'])
@permission_classes([AllowAny])
def register_view(request):
    """Register a new user (customer or supplier)"""
    serializer = UserRegistrationSerializer(
        data=request.data,
        context={
            'request': request,
            'ip_address': get_client_ip(request)
        }
    )
    if serializer.is_valid():
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'message': 'Registration successful',
            'token': token.key,
            'user': {
                'id': user.id,
                'email': user.email,
                'user_type': user.profile.user_type
            }
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    """Login with email and password"""
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        email = serializer.validated_data['email']
        password = serializer.validated_data['password']
        
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
        
        user = authenticate(username=user.username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                token, _ = Token.objects.get_or_create(user=user)
                return Response({
                    'message': 'Login successful',
                    'token': token.key,
                    'user': {
                        'id': user.id,
                        'email': user.email,
                        'user_type': user.profile.user_type if hasattr(user, 'profile') else 'customer'
                    }
                })
            return Response({'error': 'Account is disabled'}, status=status.HTTP_403_FORBIDDEN)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout_view(request):
    """Logout and invalidate token"""
    try:
        request.user.auth_token.delete()
    except:
        pass
    logout(request)
    return Response({'message': 'Logged out successfully'})


@api_view(['POST'])
@permission_classes([AllowAny])
def forgot_password_view(request):
    """Request password reset email"""
    serializer = PasswordResetRequestSerializer(data=request.data)
    if serializer.is_valid():
        email = serializer.validated_data['email']
        try:
            user = User.objects.get(email=email)
            # Create reset token
            token = PasswordResetToken.objects.create(
                user=user,
                token=uuid.uuid4().hex,
                expires_at=timezone.now() + timezone.timedelta(hours=24)
            )
            # TODO: Send email with reset link
            return Response({
                'message': 'If an account exists with this email, a password reset link has been sent.',
                'token': token.token  # In production, don't return this - send via email
            })
        except User.DoesNotExist:
            pass
        return Response({'message': 'If an account exists with this email, a password reset link has been sent.'})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([AllowAny])
def reset_password_view(request):
    """Reset password with token"""
    serializer = PasswordResetConfirmSerializer(data=request.data)
    if serializer.is_valid():
        token_str = serializer.validated_data['token']
        try:
            token = PasswordResetToken.objects.get(token=token_str)
            if token.is_valid():
                user = token.user
                user.set_password(serializer.validated_data['password'])
                user.save()
                token.used_at = timezone.now()
                token.save()
                return Response({'message': 'Password reset successful'})
            return Response({'error': 'Token has expired'}, status=status.HTTP_400_BAD_REQUEST)
        except PasswordResetToken.DoesNotExist:
            return Response({'error': 'Invalid token'}, status=status.HTTP_400_BAD_REQUEST)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def verify_email_view(request):
    """Verify email with token"""
    token = request.data.get('token')
    if not token:
        return Response({'error': 'Token required'}, status=status.HTTP_400_BAD_REQUEST)
    
    profile = request.user.profile
    if profile.email_verification_token == token:
        profile.email_verified = True
        profile.email_verification_token = ''
        profile.save()
        return Response({'message': 'Email verified successfully'})
    return Response({'error': 'Invalid token'}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_account_view(request):
    """Delete user account"""
    user = request.user
    # Anonymize instead of delete to preserve referential integrity
    user.email = f"deleted_{user.id}@anonymized.com"
    user.username = f"deleted_{user.id}"
    user.first_name = "Deleted"
    user.last_name = "User"
    user.is_active = False
    user.set_unusable_password()
    user.save()
    
    if hasattr(user, 'profile'):
        user.profile.phone = ''
        user.profile.address = ''
        user.profile.save()
    
    logout(request)
    return Response({'message': 'Account deleted successfully'})


# =============================================
# PROFILE VIEWS
# =============================================

class ProfileView(generics.RetrieveUpdateAPIView):
    """Get and update current user profile"""
    serializer_class = ProfileSerializer
    permission_classes = [IsAuthenticated]
    
    def get_object(self):
        return self.request.user.profile


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def change_password_view(request):
    """Change user password"""
    serializer = ChangePasswordSerializer(data=request.data)
    if serializer.is_valid():
        if not request.user.check_password(serializer.validated_data['old_password']):
            return Response({'error': 'Current password is incorrect'}, status=status.HTTP_400_BAD_REQUEST)
        
        request.user.set_password(serializer.validated_data['new_password'])
        request.user.save()
        return Response({'message': 'Password changed successfully'})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# =============================================
# OFFICE VIEWS
# =============================================

class OfficeViewSet(viewsets.ReadOnlyModelViewSet):
    """List and retrieve offices"""
    queryset = Office.objects.filter(is_approved=True, is_blocked=False)
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'location']
    ordering_fields = ['name', 'rating', 'created_at']
    ordering = ['-rating']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return OfficeDetailSerializer
        return OfficeListSerializer


class OfficeRatingView(generics.CreateAPIView):
    """Rate an office"""
    serializer_class = CreateOfficeRatingSerializer
    permission_classes = [IsAuthenticated, IsRenter]
    
    def perform_create(self, serializer):
        office = get_object_or_404(Office, pk=self.kwargs['office_id'])
        serializer.save(office=office, user=self.request.user)
        office.update_rating()


# =============================================
# CAR VIEWS
# =============================================

class CarViewSet(viewsets.ModelViewSet):
    """CRUD operations for cars"""
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['brand', 'fuel_type', 'transmission_type', 'body_type', 'number_of_seats', 'is_available']
    search_fields = ['brand', 'model', 'location']
    ordering_fields = ['price_per_day', 'avg_rating', 'year', 'created_at']
    ordering = ['-created_at']
    
    def get_queryset(self):
        queryset = Car.objects.filter(office__is_approved=True, office__is_blocked=False)
        
        # Apply additional filters
        min_price = self.request.query_params.get('min_price')
        max_price = self.request.query_params.get('max_price')
        min_year = self.request.query_params.get('min_year')
        max_year = self.request.query_params.get('max_year')
        office_id = self.request.query_params.get('office_id')
        
        if min_price:
            queryset = queryset.filter(price_per_day__gte=min_price)
        if max_price:
            queryset = queryset.filter(price_per_day__lte=max_price)
        if min_year:
            queryset = queryset.filter(year__gte=min_year)
        if max_year:
            queryset = queryset.filter(year__lte=max_year)
        if office_id:
            queryset = queryset.filter(office_id=office_id)
        
        return queryset
    
    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return CarCreateUpdateSerializer
        if self.action == 'retrieve':
            return CarDetailSerializer
        return CarListSerializer
    
    def get_permissions(self):
        if self.action in ['create']:
            return [IsAuthenticated(), IsSupplier()]
        if self.action in ['update', 'partial_update', 'destroy']:
            return [IsAuthenticated(), IsOwnerOfCarOrAdmin()]
        return [AllowAny()]
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated, IsSupplier])
    def upload_images(self, request, pk=None):
        """Upload images for a car"""
        car = self.get_object()
        images = request.FILES.getlist('images')
        
        for i, image in enumerate(images):
            CarImage.objects.create(car=car, image=image, sort_order=i)
        
        return Response({'message': f'{len(images)} images uploaded'})
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated, IsSupplier])
    def upload_insurance(self, request, pk=None):
        """Upload insurance document for a car"""
        car = self.get_object()
        document = request.FILES.get('document')
        
        if not document:
            return Response({'error': 'Document required'}, status=status.HTTP_400_BAD_REQUEST)
        
        doc = CarInsuranceDoc.objects.create(car=car, document=document)
        return Response(CarInsuranceDocSerializer(doc).data, status=status.HTTP_201_CREATED)
    
    @action(detail=True, methods=['get'])
    def reviews(self, request, pk=None):
        """Get reviews for a car"""
        car = self.get_object()
        reviews = car.reviews.filter(status='approved')
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def check_availability(self, request, pk=None):
        """Check if car is available for given dates"""
        car = self.get_object()
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        
        if not start_date or not end_date:
            return Response({'error': 'start_date and end_date required'}, status=status.HTTP_400_BAD_REQUEST)
        
        from datetime import datetime
        start = datetime.strptime(start_date, '%Y-%m-%d').date()
        end = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        is_available = car.is_available_for_dates(start, end)
        return Response({'available': is_available})


# =============================================
# BOOKING VIEWS
# =============================================

class BookingViewSet(viewsets.ModelViewSet):
    """CRUD operations for bookings"""
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'profile') and user.profile.user_type == 'owner':
            return Booking.objects.filter(supplier=user)
        return Booking.objects.filter(user=user)
    
    def get_serializer_class(self):
        if self.action == 'create':
            return CreateBookingSerializer
        if self.action == 'retrieve':
            return BookingDetailSerializer
        return BookingListSerializer
    
    @action(detail=False, methods=['get'])
    def history(self, request):
        """Get booking history"""
        bookings = self.get_queryset().filter(status__in=['completed', 'cancelled'])
        serializer = BookingListSerializer(bookings, many=True, context={'request': request})
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def active(self, request):
        """Get active/upcoming bookings"""
        bookings = self.get_queryset().filter(status__in=['pending', 'confirmed', 'approved'])
        serializer = BookingListSerializer(bookings, many=True, context={'request': request})
        return Response(serializer.data)
    
    @action(detail=True, methods=['put'])
    def cancel(self, request, pk=None):
        """Cancel a booking"""
        booking = self.get_object()
        
        if booking.status in ['completed', 'cancelled']:
            return Response({'error': 'Cannot cancel this booking'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Calculate refund based on cancellation policy
        days_until_start = (booking.start_date - timezone.now().date()).days
        
        refund_percentage = 0
        if days_until_start >= 7:
            refund_percentage = 100
        elif days_until_start >= 3:
            refund_percentage = 50
        
        booking.status = 'cancelled'
        booking.save()
        
        # Create refund if payment exists
        payment = booking.payments.filter(status='paid').first()
        if payment and refund_percentage > 0:
            refund_amount = payment.amount * (refund_percentage / 100)
            payment.status = 'partial_refund' if refund_percentage < 100 else 'refunded'
            payment.refund_amount = refund_amount
            payment.refunded_at = timezone.now()
            payment.save()
            
            return Response({
                'message': 'Booking cancelled',
                'refund_percentage': refund_percentage,
                'refund_amount': str(refund_amount)
            })
        
        return Response({'message': 'Booking cancelled', 'refund_percentage': refund_percentage})
    
    @action(detail=True, methods=['post'])
    def extend(self, request, pk=None):
        """Request booking extension"""
        booking = self.get_object()
        
        if booking.status != 'approved':
            return Response({'error': 'Can only extend approved bookings'}, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = CreateExtensionSerializer(data=request.data, context={'booking': booking})
        if serializer.is_valid():
            extension = BookingExtension.objects.create(
                booking=booking,
                original_end_date=booking.end_date,
                requested_end_date=serializer.validated_data['requested_end_date']
            )
            extension.calculate_extra()
            extension.save()
            
            return Response(BookingExtensionSerializer(extension).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['get'])
    def agreement(self, request, pk=None):
        """Get rental agreement"""
        booking = self.get_object()
        if hasattr(booking, 'agreement'):
            return Response(RentalAgreementSerializer(booking.agreement).data)
        return Response({'error': 'No agreement found'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=True, methods=['post'], url_path='agreement/sign')
    def sign_agreement(self, request, pk=None):
        """Sign rental agreement"""
        booking = self.get_object()
        
        if not hasattr(booking, 'agreement'):
            return Response({'error': 'No agreement found'}, status=status.HTTP_404_NOT_FOUND)
        
        agreement = booking.agreement
        ip = get_client_ip(request)
        
        if request.user == booking.user:
            agreement.renter_signed_at = timezone.now()
            agreement.renter_signature_ip = ip
        elif request.user == booking.supplier:
            agreement.supplier_signed_at = timezone.now()
            agreement.supplier_signature_ip = ip
        else:
            return Response({'error': 'Unauthorized'}, status=status.HTTP_403_FORBIDDEN)
        
        agreement.save()
        return Response(RentalAgreementSerializer(agreement).data)
    
    @action(detail=True, methods=['post'], url_path='damage/pre')
    def pre_damage_report(self, request, pk=None):
        """Submit pre-rental damage report"""
        booking = self.get_object()
        request.data['report_type'] = 'pre_rental'
        serializer = CreateDamageReportSerializer(
            data=request.data,
            context={'request': request, 'booking': booking}
        )
        if serializer.is_valid():
            report = serializer.save()
            return Response(DamageReportSerializer(report).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'], url_path='damage/post')
    def post_damage_report(self, request, pk=None):
        """Submit post-rental damage report"""
        booking = self.get_object()
        request.data['report_type'] = 'post_rental'
        serializer = CreateDamageReportSerializer(
            data=request.data,
            context={'request': request, 'booking': booking}
        )
        if serializer.is_valid():
            report = serializer.save()
            return Response(DamageReportSerializer(report).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# =============================================
# PAYMENT VIEWS
# =============================================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def process_payment(request):
    """Process payment for a booking"""
    serializer = CreatePaymentSerializer(data=request.data)
    if serializer.is_valid():
        booking_id = serializer.validated_data['booking_id']
        booking = get_object_or_404(Booking, id=booking_id, user=request.user)
        
        # Simulate payment processing
        payment = Payment.objects.create(
            booking=booking,
            user=request.user,
            amount=booking.total_amount,
            provider='simulated',
            provider_txn_id=f"TXN_{uuid.uuid4().hex[:12]}",
            status='paid'
        )
        
        # Create receipt
        receipt = Receipt.objects.create(payment=payment)
        
        # Update booking status
        booking.status = 'confirmed'
        booking.save()
        
        # Create notification
        Notification.objects.create(
            user=request.user,
            notification_type='payment_success',
            channel='in_app',
            title='Payment Successful',
            message=f'Your payment of {payment.amount} {payment.currency} for booking {booking.booking_ref} was successful.',
            data={'booking_id': booking.id, 'payment_id': payment.id}
        )
        
        return Response({
            'message': 'Payment successful',
            'payment': PaymentSerializer(payment).data,
            'receipt': ReceiptSerializer(receipt).data
        })
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def payment_history(request):
    """Get payment/transaction history"""
    payments = Payment.objects.filter(user=request.user)
    serializer = PaymentSerializer(payments, many=True)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_receipt(request, payment_id):
    """Get receipt for a payment"""
    payment = get_object_or_404(Payment, id=payment_id, user=request.user)
    if hasattr(payment, 'receipt'):
        return Response(ReceiptSerializer(payment.receipt).data)
    return Response({'error': 'Receipt not found'}, status=status.HTTP_404_NOT_FOUND)


# =============================================
# REVIEW VIEWS
# =============================================

class ReviewViewSet(viewsets.ModelViewSet):
    """CRUD operations for reviews"""
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Review.objects.filter(user=self.request.user)
    
    def get_serializer_class(self):
        if self.action == 'create':
            return CreateReviewSerializer
        return ReviewSerializer


# =============================================
# FAVORITE VIEWS
# =============================================

class FavoriteViewSet(viewsets.ModelViewSet):
    """Manage user favorites"""
    serializer_class = FavoriteSerializer
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post', 'delete']
    
    def get_queryset(self):
        return Favorite.objects.filter(user=self.request.user)
    
    def create(self, request):
        car_id = request.data.get('car_id')
        car = get_object_or_404(Car, id=car_id)
        
        favorite, created = Favorite.objects.get_or_create(user=request.user, car=car)
        
        if created:
            return Response(FavoriteSerializer(favorite).data, status=status.HTTP_201_CREATED)
        return Response({'message': 'Already in favorites'})
    
    @action(detail=False, methods=['delete'], url_path='car/(?P<car_id>[^/.]+)')
    def remove_by_car(self, request, car_id=None):
        """Remove car from favorites by car ID"""
        deleted, _ = Favorite.objects.filter(user=request.user, car_id=car_id).delete()
        if deleted:
            return Response({'message': 'Removed from favorites'})
        return Response({'error': 'Not in favorites'}, status=status.HTTP_404_NOT_FOUND)


# =============================================
# RECOMMENDATION VIEWS
# =============================================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_recommendations(request):
    """Get personalized car recommendations"""
    user = request.user
    
    # Get user's favorite brands and body types
    favorites = Favorite.objects.filter(user=user).select_related('car')
    favorite_brands = set(f.car.brand for f in favorites)
    favorite_body_types = set(f.car.body_type for f in favorites)
    
    # Get brands from past bookings
    past_bookings = Booking.objects.filter(user=user, status='completed').select_related('car')
    booked_brands = set(b.car.brand for b in past_bookings)
    
    all_preferred_brands = favorite_brands | booked_brands
    
    # Build recommendations
    recommendations = []
    
    # 1. Cars from preferred brands
    if all_preferred_brands:
        similar_cars = Car.objects.filter(
            brand__in=all_preferred_brands,
            is_available=True,
            office__is_approved=True
        ).exclude(
            id__in=[f.car_id for f in favorites]
        )[:5]
        
        for car in similar_cars:
            recommendations.append({
                'car': CarListSerializer(car, context={'request': request}).data,
                'reason': f'Similar to cars you like ({car.brand})'
            })
    
    # 2. Popular cars (high ratings)
    popular_cars = Car.objects.filter(
        is_available=True,
        office__is_approved=True,
        avg_rating__gte=4.0
    ).order_by('-avg_rating')[:5]
    
    for car in popular_cars:
        if not any(r['car']['id'] == car.id for r in recommendations):
            recommendations.append({
                'car': CarListSerializer(car, context={'request': request}).data,
                'reason': 'Highly rated'
            })
    
    return Response(recommendations[:10])


# =============================================
# NOTIFICATION VIEWS
# =============================================

class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    """View and manage notifications"""
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)
    
    @action(detail=True, methods=['post'])
    def mark_read(self, request, pk=None):
        """Mark notification as read"""
        notification = self.get_object()
        notification.mark_as_read()
        return Response({'message': 'Marked as read'})
    
    @action(detail=False, methods=['post'])
    def mark_all_read(self, request):
        """Mark all notifications as read"""
        self.get_queryset().filter(is_read=False).update(is_read=True, read_at=timezone.now())
        return Response({'message': 'All marked as read'})
    
    @action(detail=False, methods=['get'])
    def unread_count(self, request):
        """Get unread notification count"""
        count = self.get_queryset().filter(is_read=False).count()
        return Response({'count': count})


# =============================================
# SUPPORT VIEWS
# =============================================

class SupportTicketViewSet(viewsets.ModelViewSet):
    """Create and view support tickets"""
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return SupportTicket.objects.filter(user=self.request.user)
    
    def get_serializer_class(self):
        if self.action == 'create':
            return CreateSupportTicketSerializer
        return SupportTicketSerializer


class FAQViewSet(viewsets.ReadOnlyModelViewSet):
    """Browse FAQ items"""
    queryset = FAQItem.objects.filter(is_active=True)
    serializer_class = FAQItemSerializer
    permission_classes = [AllowAny]
    filter_backends = [filters.SearchFilter]
    search_fields = ['question', 'answer', 'tags']


# =============================================
# MAP VIEWS
# =============================================

@api_view(['GET'])
@permission_classes([AllowAny])
def map_cars(request):
    """Get cars for map display with location data"""
    cars = Car.objects.filter(
        is_available=True,
        office__is_approved=True,
        lat__isnull=False,
        lng__isnull=False
    )
    
    # Optional filters
    brand = request.query_params.get('brand')
    fuel_type = request.query_params.get('fuel_type')
    max_price = request.query_params.get('max_price')
    
    if brand:
        cars = cars.filter(brand__icontains=brand)
    if fuel_type:
        cars = cars.filter(fuel_type=fuel_type)
    if max_price:
        cars = cars.filter(price_per_day__lte=max_price)
    
    serializer = CarMapSerializer(cars, many=True)
    return Response(serializer.data)


# =============================================
# ADMIN VIEWS
# =============================================

@api_view(['GET'])
@permission_classes([IsAuthenticated, IsAdmin])
def admin_analytics(request):
    """Get system analytics for admin dashboard"""
    today = timezone.now().date()
    thirty_days_ago = today - timezone.timedelta(days=30)
    
    analytics = {
        'total_users': User.objects.filter(is_active=True).count(),
        'total_cars': Car.objects.count(),
        'total_bookings': Booking.objects.count(),
        'total_revenue': Payment.objects.filter(status='paid').aggregate(Sum('amount'))['amount__sum'] or 0,
        'active_bookings': Booking.objects.filter(status__in=['confirmed', 'approved']).count(),
        'pending_reviews': Review.objects.filter(status='pending').count(),
        'pending_insurance': CarInsuranceDoc.objects.filter(status='pending').count(),
        'popular_cars': list(Car.objects.annotate(
            booking_count=Count('bookings')
        ).order_by('-booking_count')[:5].values('id', 'brand', 'model', 'booking_count')),
        'recent_bookings': BookingListSerializer(
            Booking.objects.order_by('-created_at')[:10],
            many=True,
            context={'request': request}
        ).data
    }
    
    return Response(analytics)


class AdminUserViewSet(viewsets.ModelViewSet):
    """Admin user management"""
    queryset = User.objects.all()
    serializer_class = AdminUserSerializer
    permission_classes = [IsAuthenticated, IsAdmin]
    
    @action(detail=True, methods=['put'])
    def toggle_active(self, request, pk=None):
        """Toggle user active status"""
        user = self.get_object()
        user.is_active = not user.is_active
        user.save()
        return Response({'active': user.is_active})
    
    @action(detail=True, methods=['put'])
    def ban(self, request, pk=None):
        """Ban a user"""
        user = self.get_object()
        user.is_active = False
        user.save()
        return Response({'message': f'User {user.username} banned'})


class AdminCarViewSet(viewsets.ModelViewSet):
    """Admin car management"""
    queryset = Car.objects.all()
    serializer_class = CarDetailSerializer
    permission_classes = [IsAuthenticated, IsAdmin]


class AdminReviewViewSet(viewsets.ModelViewSet):
    """Admin review moderation"""
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [IsAuthenticated, IsAdmin]
    
    @action(detail=True, methods=['put'])
    def approve(self, request, pk=None):
        """Approve a review"""
        review = self.get_object()
        review.status = 'approved'
        review.moderated_by = request.user
        review.moderated_at = timezone.now()
        review.save()
        review.car.update_rating()
        return Response({'message': 'Review approved'})
    
    @action(detail=True, methods=['put'])
    def reject(self, request, pk=None):
        """Reject a review"""
        review = self.get_object()
        review.status = 'rejected'
        review.moderated_by = request.user
        review.moderated_at = timezone.now()
        review.rejection_reason = request.data.get('reason', '')
        review.save()
        return Response({'message': 'Review rejected'})


class AdminInsuranceViewSet(viewsets.ModelViewSet):
    """Admin insurance document moderation"""
    queryset = CarInsuranceDoc.objects.all()
    serializer_class = CarInsuranceDocSerializer
    permission_classes = [IsAuthenticated, IsAdmin]
    
    @action(detail=True, methods=['put'])
    def approve(self, request, pk=None):
        """Approve insurance document"""
        doc = self.get_object()
        doc.status = 'approved'
        doc.reviewed_by = request.user
        doc.reviewed_at = timezone.now()
        doc.save()
        return Response({'message': 'Insurance approved'})
    
    @action(detail=True, methods=['put'])
    def reject(self, request, pk=None):
        """Reject insurance document"""
        doc = self.get_object()
        doc.status = 'rejected'
        doc.reviewed_by = request.user
        doc.reviewed_at = timezone.now()
        doc.rejection_reason = request.data.get('reason', '')
        doc.save()
        return Response({'message': 'Insurance rejected'})


# =============================================
# UTILITY FUNCTIONS
# =============================================

def get_client_ip(request):
    """Extract client IP from request"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
