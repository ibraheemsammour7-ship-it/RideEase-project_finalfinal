import django_filters
from .models import Car

class CarFilter(django_filters.FilterSet):
    price_per_day_min = django_filters.NumberFilter(field_name='price_per_day', lookup_expr='gte')
    price_per_day_max = django_filters.NumberFilter(field_name='price_per_day', lookup_expr='lte')
    year_min = django_filters.NumberFilter(field_name='year', lookup_expr='gte')
    year_max = django_filters.NumberFilter(field_name='year', lookup_expr='lte')
    brand = django_filters.CharFilter(field_name='brand', lookup_expr='icontains')
    location = django_filters.CharFilter(field_name='location', lookup_expr='icontains')
    fuel_type = django_filters.ChoiceFilter(field_name='fuel_type', choices=[
        ('Petrol', 'Petrol'),
        ('Diesel', 'Diesel'),
        ('Electric', 'Electric'),
        ('Hybrid', 'Hybrid'),
    ])
    transmission_type = django_filters.ChoiceFilter(field_name='transmission_type', choices=[
        ('Automatic', 'Automatic'),
        ('Manual', 'Manual'),
    ])
    body_type = django_filters.ChoiceFilter(field_name='body_type', choices=[
        ('Sedan', 'Sedan'),
        ('SUV', 'SUV'),
        ('Hatchback', 'Hatchback'),
        ('Truck', 'Truck'),
        ('Van', 'Van'),
        ('Convertible', 'Convertible'),
    ])
    number_of_seats = django_filters.NumberFilter(field_name='number_of_seats', lookup_expr='exact')
    color = django_filters.CharFilter(field_name='color', lookup_expr='icontains')
    shipping = django_filters.BooleanFilter(field_name='shipping_available')

    class Meta:
        model = Car
        fields = [
            'brand', 'location', 'price_per_day',
            'fuel_type', 'transmission_type', 'body_type',
            'number_of_seats', 'color', 'shipping_available'
        ]
