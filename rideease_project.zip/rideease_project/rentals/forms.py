from .models import OfficeRating, Booking, RentalRequest, Car
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
import django_filters

from django import forms
# -----------------------
# 🔍 Car Filtering
# -----------------------
class CarFilter(django_filters.FilterSet):
    price_per_day_min = django_filters.NumberFilter(field_name='price_per_day', lookup_expr='gte')
    price_per_day_max = django_filters.NumberFilter(field_name='price_per_day', lookup_expr='lte')
    location = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Car
        fields = [
            'brand',
            'location',
            'price_per_day',
            'fuel_type',
            'transmission_type',
            'body_type',
            'number_of_seats',
            'color',
            'shipping_available'
        ]


# -----------------------
# 🚗 Car Form
# -----------------------
class CarForm(forms.ModelForm):
    battery_range = forms.IntegerField(required=False)
    engine_size = forms.DecimalField(required=False)

    class Meta:
        model = Car
        fields = [
            'brand', 'model', 'year', 'price_per_day', 'location',
            'fuel_type', 'transmission_type', 'number_of_seats',
            'engine_size', 'battery_range', 'color', 'body_type',
            'shipping_available', 'is_available', 'image'
        ]
        widgets = {
            'brand': forms.TextInput(attrs={'class': 'form-control'}),
            'model': forms.TextInput(attrs={'class': 'form-control'}),
            'year': forms.NumberInput(attrs={'class': 'form-control'}),
            'price_per_day': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'fuel_type': forms.Select(attrs={'class': 'form-control'}),
            'transmission_type': forms.Select(attrs={'class': 'form-control'}),
            'number_of_seats': forms.NumberInput(attrs={'class': 'form-control'}),
            'color': forms.TextInput(attrs={'class': 'form-control'}),
            'body_type': forms.Select(attrs={'class': 'form-control'}),
            'shipping_available': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'is_available': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'image': forms.FileInput(attrs={'class': 'form-control', 'accept': 'image/*'}),
        }

    def clean_engine_size(self):
        engine_size = self.cleaned_data.get('engine_size')
        if engine_size is not None:
            parts = str(engine_size).split('.')
            total_digits = sum(len(p) for p in parts)
            if total_digits > 4:
                raise ValidationError("Engine size must not exceed 4 digits total (including decimals).")
        return engine_size


# -----------------------
# 👤 Custom User Registration Form
# -----------------------
class CustomUserCreationForm(UserCreationForm):
    username = forms.CharField(required=False, widget=forms.HiddenInput())  # ✅ إخفاء وتجاهل الإدخال
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    user_type = forms.ChoiceField(choices=[('customer', 'Customer'), ('owner', 'Office Owner')])
    office_name = forms.CharField(required=False)
    office_location = forms.CharField(required=False)

    class Meta:
        model = User
        fields = (
            "username",  # لازم يضل موجود عشان form ترضى تشتغل، بس صار مخفي
            "first_name", "last_name", "email",
            "password1", "password2", "user_type",
            "office_name", "office_location"
        )


# -----------------------
# 📝 Rental Request Form
# -----------------------
class RentalRequestForm(forms.ModelForm):
    agreed_to_terms = forms.BooleanField(label="I agree to the terms and conditions", required=True)

    class Meta:
        model = RentalRequest
        fields = [
            'full_name', 'email', 'phone',
            'car_make', 'car_model', 'year', 'license_plate',
            'agreed_to_terms'
        ]


# -----------------------
# 📅 Booking Form
# -----------------------
class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['customer_name', 'customer_email', 'customer_phone', 'start_date', 'end_date']
        widgets = {
            'customer_name': forms.TextInput(attrs={'class': 'form-control'}),
            'customer_email': forms.EmailInput(attrs={'class': 'form-control'}),
            'customer_phone': forms.TextInput(attrs={'class': 'form-control'}),
            'start_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'end_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }


# -----------------------
# ⭐ Office Rating Form
# -----------------------
class OfficeRatingForm(forms.ModelForm):
    class Meta:
        model = OfficeRating
        fields = ['rating', 'comment']
        widgets = {
            'rating': forms.NumberInput(attrs={'min': 1, 'max': 5}),
            'comment': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['comment'].required = False  # ✅ اجعل التعليق اختياري




from django import forms

class PartnerSignupForm(forms.Form):
    company_name = forms.CharField(
        max_length=100,
        label="Company Name",
        required=True
    )
    full_name = forms.CharField(
        max_length=100,
        label="Full Legal Name",
        required=True
    )
    business_type = forms.ChoiceField(
        choices=[
            ('owner', 'Owner'),
            ('partner', 'Partner'),
            ('corporate', 'Corporate')
        ],
        label="Position in Company",
        required=True
    )
    business_email = forms.EmailField(
        label="Official Email Address",
        required=True
    )
    mobile_number = forms.CharField(
        max_length=20,
        label="Official Mobile Number",
        required=True
    )

# -----------------------
# 🔐 Email Login Form
# -----------------------
class EmailAuthenticationForm(forms.Form):
    email = forms.EmailField(label="Email", required=True)
    password = forms.CharField(label="Password", widget=forms.PasswordInput, required=True)
