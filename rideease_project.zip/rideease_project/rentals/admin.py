from django.contrib import admin
from django.utils.html import format_html
from django.urls import path
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone

from .models import (
    Profile, TermsAcceptance, PasswordResetToken,
    Office, OfficeRating,
    Car, CarImage, CarInsuranceDoc,
    Booking, RentalAgreement, BookingExtension,
    Payment, Receipt,
    Review, Favorite, RecommendationEvent,
    Notification, SupportTicket, SupportMessage, FAQItem,
    DamageReport, DamageReportImage,
    PolicyConfig, Discount,
    RentalRequest, PartnerSignup, CompanyDocument
)


# =============================================
# INLINE ADMINS
# =============================================

class CarImageInline(admin.TabularInline):
    model = CarImage
    extra = 1


class CarInsuranceDocInline(admin.TabularInline):
    model = CarInsuranceDoc
    extra = 0
    readonly_fields = ('status', 'reviewed_by', 'reviewed_at')


class DamageReportImageInline(admin.TabularInline):
    model = DamageReportImage
    extra = 1


class SupportMessageInline(admin.TabularInline):
    model = SupportMessage
    extra = 0
    readonly_fields = ('sender', 'created_at', 'is_staff_reply')


class PaymentInline(admin.TabularInline):
    model = Payment
    extra = 0
    readonly_fields = ('amount', 'status', 'created_at')


# =============================================
# USER & AUTH ADMIN
# =============================================

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'user_type', 'phone', 'email_verified', 'preferred_language', 'dark_mode', 'created_at')
    list_filter = ('user_type', 'email_verified', 'preferred_language', 'dark_mode')
    search_fields = ('user__username', 'user__email', 'phone')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(TermsAcceptance)
class TermsAcceptanceAdmin(admin.ModelAdmin):
    list_display = ('user', 'terms_version', 'accepted_at', 'ip_address')
    list_filter = ('terms_version',)
    search_fields = ('user__username',)


# =============================================
# OFFICE ADMIN
# =============================================

@admin.register(Office)
class OfficeAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner', 'location', 'average_rating', 'is_blocked', 'is_approved', 'created_at')
    list_filter = ('is_blocked', 'is_approved')
    search_fields = ('name', 'location', 'owner__username')
    actions = ['approve_selected_offices', 'block_selected_offices', 'unblock_selected_offices']

    @admin.action(description="Approve selected offices")
    def approve_selected_offices(self, request, queryset):
        queryset.update(is_approved=True)
        self.message_user(request, f"{queryset.count()} offices approved.", messages.SUCCESS)

    @admin.action(description="Block selected offices")
    def block_selected_offices(self, request, queryset):
        queryset.update(is_blocked=True)
        self.message_user(request, f"{queryset.count()} offices blocked.", messages.WARNING)

    @admin.action(description="Unblock selected offices")
    def unblock_selected_offices(self, request, queryset):
        queryset.update(is_blocked=False)
        self.message_user(request, f"{queryset.count()} offices unblocked.", messages.SUCCESS)


@admin.register(OfficeRating)
class OfficeRatingAdmin(admin.ModelAdmin):
    list_display = ('office', 'user', 'rating', 'comment', 'created_at')
    list_filter = ('rating', 'office')
    search_fields = ('office__name', 'user__username', 'comment')


# =============================================
# CAR ADMIN
# =============================================

@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ('brand', 'model', 'year', 'office', 'price_per_day', 'fuel_type', 'is_available', 'avg_rating')
    list_filter = ('fuel_type', 'transmission_type', 'body_type', 'is_available', 'office')
    search_fields = ('brand', 'model', 'office__name')
    inlines = [CarImageInline, CarInsuranceDocInline]
    readonly_fields = ('avg_rating', 'total_reviews', 'created_at', 'updated_at')
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('office', 'brand', 'model', 'year', 'color', 'image')
        }),
        ('Pricing', {
            'fields': ('price_per_day', 'daily_rate')
        }),
        ('Specifications', {
            'fields': ('fuel_type', 'transmission_type', 'body_type', 'number_of_seats', 'engine_size', 'battery_range')
        }),
        ('Location', {
            'fields': ('location', 'lat', 'lng', 'shipping_available')
        }),
        ('Status', {
            'fields': ('is_available', 'avg_rating', 'total_reviews')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(CarInsuranceDoc)
class CarInsuranceDocAdmin(admin.ModelAdmin):
    list_display = ('car', 'status', 'uploaded_at', 'reviewed_by', 'reviewed_at', 'action_buttons')
    list_filter = ('status',)
    search_fields = ('car__brand', 'car__model')
    actions = ['approve_insurance', 'reject_insurance']
    
    def action_buttons(self, obj):
        if obj.status == 'pending':
            return format_html(
                '<a class="button" href="{}">Approve</a> '
                '<a class="button" style="background:red;color:white;" href="{}">Reject</a>',
                f'approve/{obj.id}/',
                f'reject/{obj.id}/'
            )
        return obj.get_status_display()
    action_buttons.short_description = 'Actions'
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('approve/<int:doc_id>/', self.admin_site.admin_view(self.approve_doc), name='approve_insurance'),
            path('reject/<int:doc_id>/', self.admin_site.admin_view(self.reject_doc), name='reject_insurance'),
        ]
        return custom_urls + urls
    
    def approve_doc(self, request, doc_id):
        doc = get_object_or_404(CarInsuranceDoc, pk=doc_id)
        doc.status = 'approved'
        doc.reviewed_by = request.user
        doc.reviewed_at = timezone.now()
        doc.save()
        self.message_user(request, "Insurance document approved.", messages.SUCCESS)
        return redirect('..')
    
    def reject_doc(self, request, doc_id):
        doc = get_object_or_404(CarInsuranceDoc, pk=doc_id)
        doc.status = 'rejected'
        doc.reviewed_by = request.user
        doc.reviewed_at = timezone.now()
        doc.save()
        self.message_user(request, "Insurance document rejected.", messages.WARNING)
        return redirect('..')

    @admin.action(description="Approve selected insurance docs")
    def approve_insurance(self, request, queryset):
        queryset.update(status='approved', reviewed_by=request.user, reviewed_at=timezone.now())
        self.message_user(request, f"{queryset.count()} documents approved.")

    @admin.action(description="Reject selected insurance docs")
    def reject_insurance(self, request, queryset):
        queryset.update(status='rejected', reviewed_by=request.user, reviewed_at=timezone.now())
        self.message_user(request, f"{queryset.count()} documents rejected.")


# =============================================
# BOOKING ADMIN
# =============================================

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('booking_ref', 'car', 'user', 'customer_name', 'start_date', 'end_date', 'status', 'total_amount')
    list_filter = ('status', 'start_date', 'end_date')
    search_fields = ('booking_ref', 'customer_name', 'customer_email', 'car__brand', 'car__model')
    inlines = [PaymentInline]
    readonly_fields = ('booking_ref', 'created_at', 'updated_at')
    date_hierarchy = 'start_date'
    
    fieldsets = (
        ('Reference', {
            'fields': ('booking_ref', 'status')
        }),
        ('Parties', {
            'fields': ('car', 'user', 'supplier')
        }),
        ('Customer Info', {
            'fields': ('customer_name', 'customer_email', 'customer_phone')
        }),
        ('Dates', {
            'fields': ('start_date', 'end_date', 'actual_return_date')
        }),
        ('Pricing', {
            'fields': ('daily_rate', 'num_days', 'subtotal', 'discount_amount', 'late_fee', 'total_amount')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    actions = ['approve_bookings', 'reject_bookings', 'complete_bookings']
    
    @admin.action(description="Approve selected bookings")
    def approve_bookings(self, request, queryset):
        queryset.update(status='approved')
        self.message_user(request, f"{queryset.count()} bookings approved.")

    @admin.action(description="Reject selected bookings")
    def reject_bookings(self, request, queryset):
        queryset.update(status='rejected')
        self.message_user(request, f"{queryset.count()} bookings rejected.")

    @admin.action(description="Mark as completed")
    def complete_bookings(self, request, queryset):
        queryset.update(status='completed')
        self.message_user(request, f"{queryset.count()} bookings marked as completed.")


@admin.register(RentalAgreement)
class RentalAgreementAdmin(admin.ModelAdmin):
    list_display = ('booking', 'renter_signed_at', 'supplier_signed_at', 'is_fully_signed')
    list_filter = ('renter_signed_at', 'supplier_signed_at')
    search_fields = ('booking__booking_ref',)


@admin.register(BookingExtension)
class BookingExtensionAdmin(admin.ModelAdmin):
    list_display = ('booking', 'original_end_date', 'requested_end_date', 'extra_days', 'extra_amount', 'status')
    list_filter = ('status',)
    search_fields = ('booking__booking_ref',)
    actions = ['approve_extensions', 'reject_extensions']
    
    @admin.action(description="Approve selected extensions")
    def approve_extensions(self, request, queryset):
        for ext in queryset:
            ext.status = 'approved'
            ext.decided_by = request.user
            ext.decided_at = timezone.now()
            ext.save()
            # Update the booking end date
            ext.booking.end_date = ext.requested_end_date
            ext.booking.save()
        self.message_user(request, f"{queryset.count()} extensions approved.")

    @admin.action(description="Reject selected extensions")
    def reject_extensions(self, request, queryset):
        queryset.update(status='rejected', decided_by=request.user, decided_at=timezone.now())
        self.message_user(request, f"{queryset.count()} extensions rejected.")


# =============================================
# PAYMENT ADMIN
# =============================================

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'booking', 'user', 'payment_type', 'amount', 'currency', 'status', 'created_at')
    list_filter = ('status', 'payment_type', 'provider')
    search_fields = ('booking__booking_ref', 'user__username', 'provider_txn_id')
    readonly_fields = ('created_at', 'updated_at')
    
    actions = ['mark_as_paid', 'mark_as_refunded']
    
    @admin.action(description="Mark as paid")
    def mark_as_paid(self, request, queryset):
        queryset.update(status='paid')
        self.message_user(request, f"{queryset.count()} payments marked as paid.")

    @admin.action(description="Mark as refunded")
    def mark_as_refunded(self, request, queryset):
        for payment in queryset:
            payment.status = 'refunded'
            payment.refund_amount = payment.amount
            payment.refunded_at = timezone.now()
            payment.save()
        self.message_user(request, f"{queryset.count()} payments refunded.")


@admin.register(Receipt)
class ReceiptAdmin(admin.ModelAdmin):
    list_display = ('receipt_number', 'payment', 'created_at')
    search_fields = ('receipt_number', 'payment__booking__booking_ref')


# =============================================
# REVIEW ADMIN
# =============================================

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('car', 'user', 'rating', 'title', 'status', 'created_at', 'action_buttons')
    list_filter = ('status', 'rating')
    search_fields = ('car__brand', 'car__model', 'user__username', 'comment')
    readonly_fields = ('created_at', 'updated_at')
    
    def action_buttons(self, obj):
        if obj.status == 'pending':
            return format_html(
                '<a class="button" href="{}">Approve</a> '
                '<a class="button" style="background:red;color:white;" href="{}">Reject</a>',
                f'approve/{obj.id}/',
                f'reject/{obj.id}/'
            )
        return obj.get_status_display()
    action_buttons.short_description = 'Moderation'
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('approve/<int:review_id>/', self.admin_site.admin_view(self.approve_review), name='approve_review'),
            path('reject/<int:review_id>/', self.admin_site.admin_view(self.reject_review), name='reject_review'),
        ]
        return custom_urls + urls
    
    def approve_review(self, request, review_id):
        review = get_object_or_404(Review, pk=review_id)
        review.status = 'approved'
        review.moderated_by = request.user
        review.moderated_at = timezone.now()
        review.save()
        # Update car rating
        review.car.update_rating()
        self.message_user(request, "Review approved.", messages.SUCCESS)
        return redirect('..')
    
    def reject_review(self, request, review_id):
        review = get_object_or_404(Review, pk=review_id)
        review.status = 'rejected'
        review.moderated_by = request.user
        review.moderated_at = timezone.now()
        review.save()
        self.message_user(request, "Review rejected.", messages.WARNING)
        return redirect('..')

    actions = ['approve_reviews', 'reject_reviews']
    
    @admin.action(description="Approve selected reviews")
    def approve_reviews(self, request, queryset):
        queryset.update(status='approved', moderated_by=request.user, moderated_at=timezone.now())
        # Update car ratings
        for review in queryset:
            review.car.update_rating()
        self.message_user(request, f"{queryset.count()} reviews approved.")

    @admin.action(description="Reject selected reviews")
    def reject_reviews(self, request, queryset):
        queryset.update(status='rejected', moderated_by=request.user, moderated_at=timezone.now())
        self.message_user(request, f"{queryset.count()} reviews rejected.")


# =============================================
# FAVORITES & RECOMMENDATIONS ADMIN
# =============================================

@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ('user', 'car', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'car__brand', 'car__model')


@admin.register(RecommendationEvent)
class RecommendationEventAdmin(admin.ModelAdmin):
    list_display = ('user', 'car', 'reason', 'clicked', 'created_at')
    list_filter = ('reason', 'clicked')


# =============================================
# NOTIFICATION ADMIN
# =============================================

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'notification_type', 'channel', 'title', 'is_read', 'sent_at')
    list_filter = ('notification_type', 'channel', 'is_read')
    search_fields = ('user__username', 'title', 'message')


# =============================================
# SUPPORT ADMIN
# =============================================

@admin.register(SupportTicket)
class SupportTicketAdmin(admin.ModelAdmin):
    list_display = ('ticket_number', 'user', 'subject', 'category', 'priority', 'status', 'assigned_to', 'created_at')
    list_filter = ('status', 'priority', 'category')
    search_fields = ('ticket_number', 'user__username', 'subject')
    inlines = [SupportMessageInline]
    readonly_fields = ('ticket_number', 'created_at', 'updated_at')
    
    actions = ['mark_in_progress', 'mark_resolved', 'mark_closed']
    
    @admin.action(description="Mark as In Progress")
    def mark_in_progress(self, request, queryset):
        queryset.update(status='in_progress', assigned_to=request.user)
        self.message_user(request, f"{queryset.count()} tickets marked as in progress.")

    @admin.action(description="Mark as Resolved")
    def mark_resolved(self, request, queryset):
        queryset.update(status='resolved', resolved_at=timezone.now())
        self.message_user(request, f"{queryset.count()} tickets resolved.")

    @admin.action(description="Mark as Closed")
    def mark_closed(self, request, queryset):
        queryset.update(status='closed')
        self.message_user(request, f"{queryset.count()} tickets closed.")


@admin.register(FAQItem)
class FAQItemAdmin(admin.ModelAdmin):
    list_display = ('question', 'category', 'order', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('question', 'answer', 'tags')
    list_editable = ('order', 'is_active')


# =============================================
# DAMAGE REPORT ADMIN
# =============================================

@admin.register(DamageReport)
class DamageReportAdmin(admin.ModelAdmin):
    list_display = ('booking', 'report_type', 'reported_by', 'reporter', 'has_damage', 'created_at')
    list_filter = ('report_type', 'reported_by', 'has_damage')
    search_fields = ('booking__booking_ref', 'notes')
    inlines = [DamageReportImageInline]


# =============================================
# POLICY & DISCOUNT ADMIN
# =============================================

@admin.register(PolicyConfig)
class PolicyConfigAdmin(admin.ModelAdmin):
    list_display = ('key', 'description', 'is_active', 'updated_at')
    list_filter = ('is_active',)
    search_fields = ('key', 'description')


@admin.register(Discount)
class DiscountAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'discount_type', 'value', 'start_date', 'end_date', 'is_active', 'current_uses', 'max_uses')
    list_filter = ('discount_type', 'is_active')
    search_fields = ('code', 'name')
    filter_horizontal = ('applicable_cars', 'applicable_offices')


# =============================================
# LEGACY MODELS ADMIN
# =============================================

@admin.register(RentalRequest)
class RentalRequestAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'car_make', 'car_model', 'year', 'status', 'approve_and_add_button')
    list_filter = ('status', 'submitted_at')
    actions = ['approve_selected_requests']

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('approve/<int:request_id>/', self.admin_site.admin_view(self.process_approval), name='approve_rentalrequest'),
        ]
        return custom_urls + urls

    def approve_and_add_button(self, obj):
        if obj.status == 'pending':
            return format_html(
                '<a class="button" href="{}">Approve & Add Car</a>',
                f'approve/{obj.id}/'
            )
        return "✓ Already Approved"
    approve_and_add_button.short_description = 'Action'

    def process_approval(self, request, request_id):
        rental_request = get_object_or_404(RentalRequest, pk=request_id)

        if rental_request.status == 'approved':
            self.message_user(request, "This request is already approved.", level=messages.WARNING)
            return redirect('..')

        # Get the first office to associate the car with
        office = Office.objects.first()
        if office:
            Car.objects.create(
                brand=rental_request.car_make,
                model=rental_request.car_model,
                year=rental_request.year,
                price_per_day=0.00,
                location="Unknown",
                is_available=True,
                office=office
            )

            rental_request.status = 'approved'
            rental_request.save()

            self.message_user(request, f"✅ Car '{rental_request.car_make} {rental_request.car_model}' added and request approved.", level=messages.SUCCESS)
        else:
            self.message_user(request, "No office available to assign the car.", level=messages.ERROR)
        
        return redirect('..')


@admin.register(PartnerSignup)
class PartnerSignupAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'full_name', 'business_email', 'business_type', 'mobile_number', 'license', 'is_approved', 'submitted_at')
    list_filter = ('is_approved', 'business_type')
    search_fields = ('company_name', 'business_email')
    actions = ['approve_partners']
    
    @admin.action(description="Approve selected partners")
    def approve_partners(self, request, queryset):
        queryset.update(is_approved=True)
        self.message_user(request, f"{queryset.count()} partners approved.")


@admin.register(CompanyDocument)
class CompanyDocumentAdmin(admin.ModelAdmin):
    list_display = ('company_name', 'business_license_link', 'registration_certificate_link', 'uploaded_at')
    search_fields = ('company_name',)

    def business_license_link(self, obj):
        if obj.business_license:
            return format_html('<a href="{}" target="_blank">View License</a>', obj.business_license.url)
        return "No file"
    business_license_link.short_description = "Business License"

    def registration_certificate_link(self, obj):
        if obj.registration_certificate:
            return format_html('<a href="{}" target="_blank">View Certificate</a>', obj.registration_certificate.url)
        return "No file"
    registration_certificate_link.short_description = "Registration Certificate"