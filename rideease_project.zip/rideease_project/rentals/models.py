from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from decimal import Decimal
import uuid


# =============================================
# USER & AUTH MODELS
# =============================================

class Profile(models.Model):
    """Extended user profile with role and preferences"""
    USER_TYPES = (
        ('customer', 'Customer'),
        ('owner', 'Office Owner'),
        ('admin', 'Admin'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=10, choices=USER_TYPES, default='customer')
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)
    
    # Email verification
    email_verified = models.BooleanField(default=False)
    email_verification_token = models.CharField(max_length=100, blank=True)
    email_verification_sent_at = models.DateTimeField(null=True, blank=True)
    
    # Preferences
    preferred_language = models.CharField(max_length=5, default='en', choices=[('en', 'English'), ('ar', 'Arabic')])
    dark_mode = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username} - {self.user_type}"


class TermsAcceptance(models.Model):
    """Track terms and conditions acceptance per user"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='terms_acceptances')
    terms_version = models.CharField(max_length=20)
    accepted_at = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)

    class Meta:
        ordering = ['-accepted_at']

    def __str__(self):
        return f"{self.user.username} accepted v{self.terms_version}"


class PasswordResetToken(models.Model):
    """Custom password reset tokens with expiry tracking"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reset_tokens')
    token = models.CharField(max_length=100, unique=True)
    expires_at = models.DateTimeField()
    used_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_valid(self):
        return self.used_at is None and self.expires_at > timezone.now()

    def __str__(self):
        return f"Reset token for {self.user.username}"


# =============================================
# OFFICE & LOCATION MODELS
# =============================================

class Office(models.Model):
    """Rental office/agency belonging to a supplier"""
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='offices')
    rating = models.FloatField(default=0.0)
    is_blocked = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def average_rating(self):
        ratings = self.ratings.all()
        if ratings.exists():
            return round(sum(r.rating for r in ratings) / ratings.count(), 2)
        return 0

    def update_rating(self):
        """Recalculate and save average rating"""
        self.rating = self.average_rating()
        self.save()


class OfficeRating(models.Model):
    """Rating for an office from a customer"""
    office = models.ForeignKey(Office, on_delete=models.CASCADE, related_name='ratings')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['office', 'user']

    def __str__(self):
        return f"{self.office.name} - {self.rating}★"


# =============================================
# CAR MODELS
# =============================================

class Car(models.Model):
    """Vehicle listing with all specifications"""
    FUEL_TYPES = [
        ('Petrol', 'Petrol'),
        ('Diesel', 'Diesel'),
        ('Electric', 'Electric'),
        ('Hybrid', 'Hybrid'),
    ]
    TRANSMISSION_TYPES = [
        ('Automatic', 'Automatic'),
        ('Manual', 'Manual'),
    ]
    BODY_TYPES = [
        ('Sedan', 'Sedan'),
        ('SUV', 'SUV'),
        ('Hatchback', 'Hatchback'),
        ('Truck', 'Truck'),
        ('Van', 'Van'),
        ('Convertible', 'Convertible'),
        ('Coupe', 'Coupe'),
        ('Wagon', 'Wagon'),
    ]

    office = models.ForeignKey(Office, on_delete=models.CASCADE, related_name='cars')
    brand = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    year = models.IntegerField()
    
    # Pricing
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2)
    daily_rate = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('30.00'))
    
    # Location
    location = models.CharField(max_length=200)
    lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    
    # Specifications
    fuel_type = models.CharField(max_length=50, choices=FUEL_TYPES, default='Petrol')
    transmission_type = models.CharField(max_length=50, choices=TRANSMISSION_TYPES, default='Automatic')
    number_of_seats = models.PositiveIntegerField(default=5)
    engine_size = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)
    battery_range = models.PositiveIntegerField(null=True, blank=True, help_text="Range in km for electric vehicles")
    color = models.CharField(max_length=50, default='White')
    body_type = models.CharField(max_length=50, choices=BODY_TYPES, default='Sedan')
    
    # Features
    shipping_available = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True)
    
    # Primary image (legacy support)
    image = models.ImageField(upload_to='car_images/', null=True, blank=True)
    
    # Computed fields
    avg_rating = models.FloatField(default=0.0)
    total_reviews = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.brand} {self.model} ({self.year})"

    def update_rating(self):
        """Recalculate rating from approved reviews"""
        reviews = self.reviews.filter(status='approved')
        if reviews.exists():
            self.avg_rating = round(sum(r.rating for r in reviews) / reviews.count(), 2)
            self.total_reviews = reviews.count()
        else:
            self.avg_rating = 0
            self.total_reviews = 0
        self.save()

    def is_available_for_dates(self, start_date, end_date, exclude_booking_id=None):
        """Check if car is available for given date range"""
        bookings = self.bookings.filter(
            status__in=['pending', 'confirmed', 'approved'],
            start_date__lte=end_date,
            end_date__gte=start_date
        )
        if exclude_booking_id:
            bookings = bookings.exclude(id=exclude_booking_id)
        return not bookings.exists()


class CarImage(models.Model):
    """Multiple images for a car listing"""
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='car_images/')
    sort_order = models.PositiveIntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['sort_order']

    def __str__(self):
        return f"Image for {self.car}"


class CarInsuranceDoc(models.Model):
    """Insurance documentation for vehicles"""
    STATUS_CHOICES = [
        ('pending', 'Pending Review'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='insurance_docs')
    document = models.FileField(upload_to='car_insurance/')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_insurance')
    reviewed_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)

    def __str__(self):
        return f"Insurance for {self.car} - {self.status}"


# =============================================
# BOOKING MODELS
# =============================================

class Booking(models.Model):
    """Car rental booking"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
        ('completed', 'Completed'),
        ('expired', 'Expired'),
    ]

    # Reference
    booking_ref = models.CharField(max_length=20, blank=True, default='')
    
    # Parties
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='bookings')
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='bookings')
    supplier = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='supplier_bookings')
    
    # Customer info (for non-logged users or override)
    customer_name = models.CharField(max_length=100)
    customer_email = models.EmailField()
    customer_phone = models.CharField(max_length=20)
    
    # Dates
    start_date = models.DateField()
    end_date = models.DateField()
    actual_return_date = models.DateField(null=True, blank=True)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Pricing
    daily_rate = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    num_days = models.PositiveIntegerField(default=1)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    late_fee = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Booking {self.booking_ref} - {self.car}"

    def save(self, *args, **kwargs):
        if not self.booking_ref:
            self.booking_ref = f"BK{uuid.uuid4().hex[:8].upper()}"
        if not self.supplier and self.car:
            self.supplier = self.car.office.owner
        super().save(*args, **kwargs)

    def calculate_cost(self):
        """Calculate booking costs"""
        delta = (self.end_date - self.start_date).days + 1
        self.num_days = max(delta, 1)
        self.daily_rate = self.car.price_per_day
        self.subtotal = self.daily_rate * self.num_days
        self.total_amount = self.subtotal - self.discount_amount + self.late_fee
        return self.total_amount


class RentalAgreement(models.Model):
    """Digital rental agreement/contract"""
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name='agreement')
    agreement_pdf = models.FileField(upload_to='rental_agreements/', null=True, blank=True)
    terms_snapshot = models.JSONField(default=dict)  # Snapshot of terms at booking time
    
    # Signatures
    renter_signed_at = models.DateTimeField(null=True, blank=True)
    renter_signature_ip = models.GenericIPAddressField(null=True, blank=True)
    supplier_signed_at = models.DateTimeField(null=True, blank=True)
    supplier_signature_ip = models.GenericIPAddressField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Agreement for {self.booking.booking_ref}"

    @property
    def is_fully_signed(self):
        return self.renter_signed_at and self.supplier_signed_at


class BookingExtension(models.Model):
    """Request to extend a booking"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='extensions')
    original_end_date = models.DateField()
    requested_end_date = models.DateField()
    
    # Pricing
    extra_days = models.PositiveIntegerField(default=0)
    extra_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    decided_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Extension for {self.booking.booking_ref}"

    def calculate_extra(self):
        self.extra_days = (self.requested_end_date - self.original_end_date).days
        self.extra_amount = self.booking.daily_rate * self.extra_days
        return self.extra_amount


# =============================================
# PAYMENT MODELS
# =============================================

class Payment(models.Model):
    """Payment record for a booking"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('paid', 'Paid'),
        ('failed', 'Failed'),
        ('refunded', 'Refunded'),
        ('partial_refund', 'Partial Refund'),
    ]
    PAYMENT_TYPES = [
        ('booking', 'Booking Payment'),
        ('extension', 'Extension Payment'),
        ('late_fee', 'Late Fee'),
        ('damage', 'Damage Payment'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='payments')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payments')
    
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPES, default='booking')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='JOD')
    
    # Provider details
    provider = models.CharField(max_length=50, default='manual')
    provider_txn_id = models.CharField(max_length=100, blank=True)
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Refund tracking
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    refund_reason = models.TextField(blank=True)
    refunded_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Payment {self.id} - {self.amount} {self.currency}"


class Receipt(models.Model):
    """Payment receipt"""
    payment = models.OneToOneField(Payment, on_delete=models.CASCADE, related_name='receipt')
    receipt_number = models.CharField(max_length=20, unique=True)
    receipt_pdf = models.FileField(upload_to='receipts/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.receipt_number:
            self.receipt_number = f"RCP{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Receipt {self.receipt_number}"


# =============================================
# REVIEW MODELS
# =============================================

class Review(models.Model):
    """Verified car review (only after completed rental)"""
    STATUS_CHOICES = [
        ('pending', 'Pending Moderation'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name='review')
    
    rating = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    title = models.CharField(max_length=100, blank=True)
    comment = models.TextField()
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    moderated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='moderated_reviews')
    moderated_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Review by {self.user.username} for {self.car}"


# =============================================
# FAVORITES & RECOMMENDATIONS
# =============================================

class Favorite(models.Model):
    """User's saved/favorite cars"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='favorites')
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='favorited_by')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'car']

    def __str__(self):
        return f"{self.user.username} ♥ {self.car}"


class RecommendationEvent(models.Model):
    """Track recommendation impressions for analytics"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recommendation_events')
    car = models.ForeignKey(Car, on_delete=models.CASCADE)
    reason = models.CharField(max_length=100)  # e.g., "similar_to_booking", "popular", "favorite_brand"
    clicked = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Recommendation: {self.car} for {self.user.username}"


# =============================================
# NOTIFICATIONS
# =============================================

class Notification(models.Model):
    """User notifications (email, SMS, in-app)"""
    TYPE_CHOICES = [
        ('booking_confirmed', 'Booking Confirmed'),
        ('booking_cancelled', 'Booking Cancelled'),
        ('payment_success', 'Payment Successful'),
        ('payment_failed', 'Payment Failed'),
        ('review_approved', 'Review Approved'),
        ('extension_approved', 'Extension Approved'),
        ('extension_rejected', 'Extension Rejected'),
        ('reminder', 'Reminder'),
        ('system', 'System Notification'),
    ]
    CHANNEL_CHOICES = [
        ('email', 'Email'),
        ('sms', 'SMS'),
        ('in_app', 'In-App'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=30, choices=TYPE_CHOICES)
    channel = models.CharField(max_length=10, choices=CHANNEL_CHOICES, default='in_app')
    
    title = models.CharField(max_length=200)
    message = models.TextField()
    data = models.JSONField(default=dict, blank=True)  # Additional context
    
    is_read = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.notification_type} for {self.user.username}"

    def mark_as_read(self):
        if not self.is_read:
            self.is_read = True
            self.read_at = timezone.now()
            self.save()


# =============================================
# SUPPORT & FAQ
# =============================================

class SupportTicket(models.Model):
    """Customer support ticket"""
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed'),
    ]
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]
    
    ticket_number = models.CharField(max_length=20, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='support_tickets')
    
    subject = models.CharField(max_length=200)
    message = models.TextField()
    category = models.CharField(max_length=50, default='general')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_tickets')
    
    # Related booking if applicable
    booking = models.ForeignKey(Booking, on_delete=models.SET_NULL, null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.ticket_number:
            self.ticket_number = f"TKT{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.ticket_number}: {self.subject}"


class SupportMessage(models.Model):
    """Messages within a support ticket"""
    ticket = models.ForeignKey(SupportTicket, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    is_staff_reply = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Message in {self.ticket.ticket_number}"


class FAQItem(models.Model):
    """Frequently Asked Questions"""
    question = models.CharField(max_length=300)
    answer = models.TextField()
    category = models.CharField(max_length=50, default='general')
    tags = models.CharField(max_length=200, blank=True, help_text="Comma-separated tags")
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', '-created_at']

    def __str__(self):
        return self.question[:50]


# =============================================
# DAMAGE REPORTS
# =============================================

class DamageReport(models.Model):
    """Pre/post rental damage documentation"""
    TYPE_CHOICES = [
        ('pre_rental', 'Pre-Rental Inspection'),
        ('post_rental', 'Post-Rental Inspection'),
    ]
    REPORTED_BY_CHOICES = [
        ('renter', 'Renter'),
        ('supplier', 'Supplier'),
    ]
    
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='damage_reports')
    report_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    reported_by = models.CharField(max_length=10, choices=REPORTED_BY_CHOICES)
    reporter = models.ForeignKey(User, on_delete=models.CASCADE)
    
    notes = models.TextField()
    fuel_level = models.CharField(max_length=20, blank=True)  # e.g., "Full", "3/4", "1/2"
    mileage = models.PositiveIntegerField(null=True, blank=True)
    
    # Damage assessment
    has_damage = models.BooleanField(default=False)
    damage_description = models.TextField(blank=True)
    estimated_repair_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.report_type} for {self.booking.booking_ref}"


class DamageReportImage(models.Model):
    """Photos attached to damage reports"""
    damage_report = models.ForeignKey(DamageReport, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='damage_reports/')
    caption = models.CharField(max_length=200, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for {self.damage_report}"


# =============================================
# POLICY & DISCOUNTS
# =============================================

class PolicyConfig(models.Model):
    """Business rules configuration"""
    key = models.CharField(max_length=50, unique=True)
    value = models.JSONField()
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.key

    @classmethod
    def get_value(cls, key, default=None):
        try:
            config = cls.objects.get(key=key, is_active=True)
            return config.value
        except cls.DoesNotExist:
            return default


class Discount(models.Model):
    """Promotional discounts"""
    DISCOUNT_TYPES = [
        ('percentage', 'Percentage'),
        ('fixed', 'Fixed Amount'),
    ]
    
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    
    discount_type = models.CharField(max_length=20, choices=DISCOUNT_TYPES, default='percentage')
    value = models.DecimalField(max_digits=10, decimal_places=2)  # Percentage or fixed amount
    
    # Validity
    start_date = models.DateField()
    end_date = models.DateField()
    
    # Constraints
    min_rental_days = models.PositiveIntegerField(default=1)
    min_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    max_uses = models.PositiveIntegerField(null=True, blank=True)
    current_uses = models.PositiveIntegerField(default=0)
    
    # Targeting
    applicable_cars = models.ManyToManyField(Car, blank=True, related_name='discounts')
    applicable_offices = models.ManyToManyField(Office, blank=True, related_name='discounts')
    
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.code}: {self.name}"

    def is_valid(self):
        today = timezone.now().date()
        if not self.is_active:
            return False
        if today < self.start_date or today > self.end_date:
            return False
        if self.max_uses and self.current_uses >= self.max_uses:
            return False
        return True

    def calculate_discount(self, amount):
        if self.discount_type == 'percentage':
            return amount * (self.value / 100)
        return min(self.value, amount)


# =============================================
# LEGACY MODELS (kept for backward compatibility)
# =============================================

class RentalRequest(models.Model):
    """Legacy: Request from office owner to add a car"""
    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    car_make = models.CharField(max_length=100)
    car_model = models.CharField(max_length=100)
    year = models.PositiveIntegerField()
    license_plate = models.CharField(max_length=20)
    agreed_to_terms = models.BooleanField(default=False)
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.full_name} - {self.car_make} {self.car_model}"


class PartnerSignup(models.Model):
    """Legacy: Partner signup request"""
    is_approved = models.BooleanField(default=False)
    company_name = models.CharField(max_length=100)
    full_name = models.CharField(max_length=100)
    business_type = models.CharField(max_length=20, choices=[
        ('owner', 'Owner'),
        ('partner', 'Partner'),
        ('corporate', 'Corporate')
    ])
    business_email = models.EmailField()
    mobile_number = models.CharField(max_length=20)
    license = models.CharField(max_length=10, choices=[('yes', 'Yes'), ('no', 'No')])
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.company_name} ({self.business_email})"


class CompanyDocument(models.Model):
    """Legacy: Company documentation upload"""
    company_name = models.CharField(max_length=100)
    business_license = models.FileField(upload_to='company_documents/business_license/')
    registration_certificate = models.FileField(upload_to='company_documents/registration_certificate/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Documents for {self.company_name}"
