import json
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.http import HttpResponseForbidden

from .models import Car, Booking, Profile, Office, OfficeRating, Favorite
from .forms import BookingForm, RentalRequestForm, CustomUserCreationForm, CarForm, OfficeRatingForm
from .filters import CarFilter
from django.http import JsonResponse

from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt  # Temporary for testing
from datetime import date
from .forms import PartnerSignupForm
from .models import PartnerSignup
from .models import CompanyDocument
from django.contrib.auth import authenticate  # تأكد إنها مستوردة
from .forms import EmailAuthenticationForm  # استدعاء الفورم الجديد
from django.contrib.auth.models import User




def login_view(request):
    if request.method == 'POST':
        form = EmailAuthenticationForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            try:
                user_obj = User.objects.get(email=email)
                user = authenticate(username=user_obj.username, password=password)
                if user is not None:
                    login(request, user)
                    messages.success(request, "Logged in successfully!")
                    return redirect('owner_dashboard' if user.profile.user_type == 'owner' else 'office_list')
                else:
                    messages.error(request, "Invalid email or password.")
            except User.DoesNotExist:
                messages.error(request, "No user found with this email.")
    else:
        form = EmailAuthenticationForm()

    return render(request, 'rentals/login.html', {'form': form})

@login_required
def booking_history_view(request):
    bookings = Booking.objects.filter(user=request.user)
    for booking in bookings:
        delta = (booking.end_date - booking.start_date).days + 1
        booking.days = delta
        booking.cost = booking.car.daily_rate * delta if booking.car.daily_rate else 0
    return render(request, 'rentals/booking_history.html', {'bookings': bookings})


@require_POST
@login_required
def ajax_rate_office(request, office_id):
    if request.user.profile.user_type == 'owner':
        return JsonResponse({'error': 'Office owners cannot rate offices.'}, status=403)

    office = get_object_or_404(Office, id=office_id)

    form = OfficeRatingForm(request.POST)

    if form.is_valid():
        rating = form.save(commit=False)
        rating.office = office
        rating.user = request.user
        rating.save()
        
        # Update office's cached average rating
        office.update_rating()
        
        return JsonResponse({'message': 'Rating submitted successfully', 'new_rating': office.rating})

    return JsonResponse({'errors': form.errors}, status=400)


def prototype_view(request):
    return render(request, 'rentals/prototype.html')

@login_required
def admin_ratings_view(request):
    if not request.user.profile.user_type == 'admin':
        return HttpResponseForbidden()
    ratings = OfficeRating.objects.all().order_by('-created_at')
    return render(request, 'rentals/admin_ratings.html', {'ratings': ratings})


@login_required
def rate_office(request, office_id):
    if request.user.profile.user_type == 'owner':
        return HttpResponseForbidden("Office owners cannot rate offices.")

    office = get_object_or_404(Office, id=office_id)

    if request.method == 'POST':
        form = OfficeRatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.office = office
            rating.user = request.user
            rating.save()
            
            # Update office's cached average rating
            office.update_rating()
            
            messages.success(request, 'Rating submitted successfully.')
            return redirect('office_cars', office_id=office.id)
    else:
        form = OfficeRatingForm()

    return render(request, 'rentals/rate_office.html', {'form': form, 'office': office})


@login_required
def approve_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, car__office__owner=request.user)
    booking.status = 'approved'
    booking.save()
    booking.car.is_available = False
    booking.car.save()
    messages.success(request, "Booking approved. Car is now unavailable.")
    return redirect('owner_dashboard')

@login_required
def reject_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, car__office__owner=request.user)
    booking.status = 'rejected'
    booking.save()
    messages.info(request, "Booking rejected.")
    return redirect('owner_dashboard')

def office_list(request):
    offices = Office.objects.filter(is_blocked=False, is_approved=True)  # ✅ عرض المكاتب المعتمدة فقط
    return render(request, 'rentals/office_list.html', {'offices': offices})
@login_required
def office_cars(request, office_id):
    office = get_object_or_404(Office, id=office_id)
    cars = Car.objects.filter(office=office, is_available=True)
    car_filter = CarFilter(request.GET, queryset=cars)
    return render(request, 'rentals/car_list.html', {
        'office': office,
        'filter': car_filter,
        'cars': car_filter.qs
    })

@login_required
def add_car(request):
    profile = request.user.profile
    office = request.user.offices.first()
    if profile.user_type != 'owner':
        messages.error(request, "Only office owners can add cars.")
        return redirect('office_list')

    if not office or not office.is_approved:
        messages.error(request, "Your office must be approved by the admin before adding cars.")
        return redirect('owner_dashboard')

    if request.method == 'POST':
        form = CarForm(request.POST, request.FILES)
        if form.is_valid():
            car = form.save(commit=False)
            car.owner = request.user
            car.office = office
            car.save()
            messages.success(request, 'Car added successfully!')
            return redirect('owner_dashboard')
    else:
        form = CarForm()
    return render(request, 'rentals/add_car.html', {'form': form})
@login_required
def edit_car(request, car_id):
    car = get_object_or_404(Car, id=car_id, office__owner=request.user)
    if request.method == 'POST':
        form = CarForm(request.POST, request.FILES, instance=car)
        if form.is_valid():
            form.save()
            messages.success(request, 'Car updated successfully!')
            return redirect('owner_dashboard')
    else:
        form = CarForm(instance=car)
    return render(request, 'rentals/edit_car.html', {'form': form, 'car': car})

@login_required
def delete_car(request, car_id):
    car = get_object_or_404(Car, id=car_id, office__owner=request.user)
    car.delete()
    messages.success(request, "Car deleted successfully.")
    return redirect('owner_dashboard')

@login_required
def owner_dashboard(request):
    try:
        profile = Profile.objects.get(user=request.user)
        if profile.user_type != 'owner':
            return HttpResponseForbidden("You are not authorized to access this page.")
    except Profile.DoesNotExist:
        return HttpResponseForbidden("Profile not found.")
    cars = Car.objects.filter(office__owner=request.user)
    return render(request, 'rentals/owner_dashboard.html', {'cars': cars})

def car_list(request):
    cars = Car.objects.filter(is_available=True, office__is_approved=True, office__is_blocked=False)
    car_filter = CarFilter(request.GET, queryset=cars)
    filtered_cars = car_filter.qs
    
    # Apply sorting
    sort_by = request.GET.get('sort', '')
    if sort_by == 'price_asc':
        filtered_cars = filtered_cars.order_by('price_per_day')
    elif sort_by == 'price_desc':
        filtered_cars = filtered_cars.order_by('-price_per_day')
    elif sort_by == 'newest':
        filtered_cars = filtered_cars.order_by('-created_at')
    elif sort_by == 'rating':
        filtered_cars = filtered_cars.order_by('-avg_rating')
    
    return render(request, 'rentals/car_list.html', {'cars': filtered_cars, 'filter': car_filter})

@login_required
def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    reviews = car.reviews.filter(status='approved').order_by('-created_at')[:10]
    return render(request, 'rentals/car_detail.html', {'car': car, 'reviews': reviews})


@login_required
def book_car(request, car_id):
    if request.user.profile.user_type == 'owner':
        messages.error(request, "Office owners are not allowed to book cars.")
        return redirect('office_list')

    car = get_object_or_404(Car, id=car_id)

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if 'preview' in request.POST and form.is_valid():
            start_date = form.cleaned_data['start_date']
            end_date = form.cleaned_data['end_date']
            num_days = (end_date - start_date).days + 1
            daily_rate = car.price_per_day or 0
            total_cost = num_days * daily_rate

            return render(request, 'rentals/booking_form.html', {
                'form': form,
                'car': car,
                'preview': True,
                'num_days': num_days,
                'daily_rate': daily_rate,
                'total_cost': total_cost
            })

        elif 'confirm' in request.POST and form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.car = car
            booking.save()
            messages.success(request, 'Car booked successfully!')
            return redirect('booking_list')

    else:
        form = BookingForm()

    return render(request, 'rentals/booking_form.html', {'form': form, 'car': car})

@login_required
def booking_list(request):
    try:
        profile = Profile.objects.get(user=request.user)
    except Profile.DoesNotExist:
        messages.error(request, "Your profile is missing. Contact support.")
        return redirect('office_list')

    if profile.user_type == 'owner':
        cars = Car.objects.filter(office__owner=request.user)
        bookings = Booking.objects.filter(car__in=cars)
    else:
        bookings = Booking.objects.filter(user=request.user)

    return render(request, 'rentals/booking_list.html', {'bookings': bookings})

@login_required
def delete_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    booking.delete()
    messages.success(request, "Booking deleted successfully.")
    return redirect('booking_list')

@login_required
def edit_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        form = BookingForm(request.POST, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, "Booking updated successfully.")
            return redirect('booking_list')
    else:
        form = BookingForm(instance=booking)
    return render(request, 'rentals/edit_booking.html', {'form': form, 'booking': booking})

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)

            # استخراج الحقول
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            email = form.cleaned_data.get('email')

            # توليد username من الاسم الأول والأخير
            username = f"{first_name.lower()}_{last_name.lower()}"

            # تعيين القيم
            user.username = username
            user.first_name = first_name
            user.last_name = last_name
            user.email = email
            user.save()

            # إنشاء الملف الشخصي
            user_type = form.cleaned_data.get('user_type')
            Profile.objects.create(user=user, user_type=user_type)

            # إذا كان مالك مكتب، أنشئ المكتب
            if user_type == 'owner':
                office_name = form.cleaned_data.get('office_name')
                office_location = form.cleaned_data.get('office_location')
                Office.objects.create(name=office_name, location=office_location, owner=user)

            # تسجيل الدخول تلقائيًا
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('office_list')

    else:
        form = CustomUserCreationForm()
    return render(request, 'rentals/register.html', {'form': form})


def rental_request_view(request):
    if request.method == 'POST':
        form = RentalRequestForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Your request has been submitted successfully!")
            return redirect('rental_request')
    else:
        form = RentalRequestForm()
    return render(request, 'rentals/rental_request.html', {'form': form})

def terms_view(request):
    return render(request, 'rentals/terms.html')

def partner_signup_view(request):
    if request.method == 'POST':
        form = PartnerSignupForm(request.POST)
        if form.is_valid():
            PartnerSignup.objects.create(**form.cleaned_data)
            messages.success(request, "Thank you for your submission!")
            return render(request, 'rentals/company_documents_page.html') # redirect to homepage
    else:
        form = PartnerSignupForm()
    return render(request, 'rentals/partner_signup.html', {'form': form})
@login_required
def company_documents_view(request):
    if request.method == 'POST':
        # later: handle saving uploaded documents here
        messages.success(request, "Documents uploaded successfully!")
        return redirect('partner_thank_you')  # or Step 3 if you have one
    return render(request, 'rentals/company_documents_page.html')
@login_required
def partner_thank_you_view(request):
    return render(request, 'rentals/submission_success.html')
@login_required
def company_documents_view(request):
    if request.method == 'POST':
        company_name = request.POST.get('company_name')
        business_license = request.FILES.get('business_license')
        registration_certificate = request.FILES.get('registration_certificate')

        if business_license and registration_certificate:
            CompanyDocument.objects.create(
                company_name=company_name,
                business_license=business_license,
                registration_certificate=registration_certificate
            )
            messages.success(request, "Documents uploaded successfully!")
        else:
            messages.warning(request, "Please upload both required documents.")

        return redirect('partner_thank_you')  # or the success page you want

    return render(request, 'rentals/company_documents_page.html')


@login_required
def payment_page(request, booking_id):
    """Display payment page for a booking"""
    booking = get_object_or_404(Booking, id=booking_id)
    
    # Only allow the booking owner to pay
    if booking.user != request.user:
        return HttpResponseForbidden("You cannot access this booking.")
    
    # Check booking status
    if booking.status not in ['pending', 'approved']:
        messages.warning(request, "This booking cannot be paid for.")
        return redirect('booking_list')
    
    # Calculate pricing if not already set
    if not booking.total_amount:
        booking.calculate_cost()
        booking.save()
    
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method', 'card')
        
        # Import models here to avoid circular import
        from .models import Payment, Receipt, Notification
        import uuid
        from django.utils import timezone
        
        if payment_method == 'card':
            # Simulate card payment (in production, integrate with Stripe/PayPal)
            card_number = request.POST.get('card_number', '').replace(' ', '')
            
            # Basic validation
            if len(card_number) < 13:
                messages.error(request, "Please enter a valid card number.")
                return render(request, 'rentals/payment.html', {'booking': booking})
            
            # Create payment record
            payment = Payment.objects.create(
                booking=booking,
                user=request.user,
                amount=booking.total_amount or booking.car.price_per_day * booking.num_days,
                provider='simulated',
                provider_txn_id=f"TXN_{uuid.uuid4().hex[:12].upper()}",
                status='paid'
            )
            
            # Create receipt
            Receipt.objects.create(payment=payment)
            
            # Update booking status
            booking.status = 'confirmed'
            booking.save()
            
            # Create notification
            Notification.objects.create(
                user=request.user,
                notification_type='payment_success',
                channel='in_app',
                title='Payment Successful',
                message=f'Your payment of {payment.amount} JOD for booking {booking.booking_ref} was successful.',
                data={'booking_id': booking.id, 'payment_id': payment.id}
            )
            
            messages.success(request, f"Payment successful! Your booking is now confirmed. Transaction ID: {payment.provider_txn_id}")
        else:
            # Cash payment - just confirm booking
            booking.status = 'confirmed'
            booking.save()
            messages.success(request, "Booking confirmed! Please pay in cash at pickup.")
        
        return redirect('booking_list')
    
    return render(request, 'rentals/payment.html', {'booking': booking})


@login_required
def review_booking(request, booking_id):
    """Submit a review for a completed booking"""
    from .models import Review
    
    booking = get_object_or_404(Booking, id=booking_id)
    
    # Verify ownership and status
    if booking.user != request.user:
        return HttpResponseForbidden("You cannot review this booking.")
    
    if booking.status != 'completed':
        messages.warning(request, "You can only review completed bookings.")
        return redirect('booking_list')
    
    # Check if already reviewed
    if hasattr(booking, 'review'):
        messages.info(request, "You have already reviewed this booking.")
        return redirect('booking_list')
    
    if request.method == 'POST':
        rating = int(request.POST.get('rating', 5))
        title = request.POST.get('title', '')
        comment = request.POST.get('comment', '')
        
        Review.objects.create(
            booking=booking,
            car=booking.car,
            user=request.user,
            rating=rating,
            title=title,
            comment=comment
        )
        
        messages.success(request, "Thank you for your review!")
        return redirect('booking_list')
    
    return render(request, 'rentals/review_form.html', {'booking': booking})


@login_required
def favorites_view(request):
    """Display user's favorite cars"""
    favorites = Favorite.objects.filter(user=request.user).select_related('car', 'car__office')
    favorite_cars = [fav.car for fav in favorites]
    return render(request, 'rentals/favorites.html', {'cars': favorite_cars})


@login_required
def edit_profile_view(request):
    """Edit user profile - FR-4"""
    profile = request.user.profile
    
    if request.method == 'POST':
        # Update user fields
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        new_email = request.POST.get('email', request.user.email)
        
        if new_email != request.user.email:
            request.user.email = new_email
            profile.email_verified = False  # Require re-verification
        
        request.user.save()
        
        # Update profile fields
        profile.phone = request.POST.get('phone', '')
        profile.address = request.POST.get('address', '')
        profile.preferred_language = request.POST.get('preferred_language', 'en')
        profile.dark_mode = 'dark_mode' in request.POST
        profile.save()
        
        messages.success(request, 'Profile updated successfully!')
        return redirect('edit_profile')
    
    return render(request, 'rentals/edit_profile.html')


@login_required
def delete_account_view(request):
    """Delete user account - FR-34"""
    if request.method == 'POST':
        password = request.POST.get('password', '')
        
        if request.user.check_password(password):
            user = request.user
            from django.contrib.auth import logout
            logout(request)
            user.delete()
            messages.success(request, 'Your account has been deleted.')
            return redirect('office_list')
        else:
            messages.error(request, 'Incorrect password. Account not deleted.')
            return redirect('edit_profile')
    
    return redirect('edit_profile')


def faq_view(request):
    """FAQ page - FR-48"""
    from .models import FAQItem
    faqs = FAQItem.objects.filter(is_active=True).order_by('order', '-created_at')
    return render(request, 'rentals/faq.html', {'faqs': faqs})


def contact_support_view(request):
    """Contact support form - FR-37"""
    from .models import SupportTicket
    
    user_bookings = []
    if request.user.is_authenticated:
        user_bookings = Booking.objects.filter(user=request.user).order_by('-created_at')[:10]
    
    if request.method == 'POST':
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        category = request.POST.get('category', 'general')
        priority = request.POST.get('priority', 'medium')
        subject = request.POST.get('subject', '')
        message = request.POST.get('message', '')
        booking_id = request.POST.get('booking_id', '')
        
        if request.user.is_authenticated:
            booking = None
            if booking_id:
                try:
                    booking = Booking.objects.get(id=booking_id, user=request.user)
                except Booking.DoesNotExist:
                    pass
            
            SupportTicket.objects.create(
                user=request.user,
                subject=subject,
                message=message,
                category=category,
                priority=priority,
                booking=booking
            )
            messages.success(request, 'Your support ticket has been submitted. We will get back to you soon!')
        else:
            # For non-authenticated users, just show success (could send email instead)
            messages.success(request, 'Your message has been received. We will contact you at the provided email.')
        
        return redirect('contact_support')
    
    return render(request, 'rentals/contact_support.html', {'user_bookings': user_bookings})


@login_required
def notifications_view(request):
    """Notifications list page - FR-28"""
    from .models import Notification
    
    notifications = Notification.objects.filter(user=request.user)
    
    # Apply filter
    filter_type = request.GET.get('filter', 'all')
    if filter_type == 'unread':
        notifications = notifications.filter(is_read=False)
    elif filter_type == 'booking':
        notifications = notifications.filter(notification_type__icontains='booking')
    elif filter_type == 'payment':
        notifications = notifications.filter(notification_type__icontains='payment')
    
    notifications = notifications.order_by('-created_at')[:50]
    
    return render(request, 'rentals/notifications.html', {'notifications': notifications})


@login_required
def analytics_dashboard_view(request):
    """Analytics dashboard for admins and owners - FR-24"""
    # Allow staff and owners
    is_owner = request.user.profile.user_type == 'owner'
    if not request.user.is_staff and not is_owner:
        return HttpResponseForbidden("Access denied.")
    
    from django.db.models import Count, Sum, Avg
    from django.db.models.functions import TruncMonth
    from django.utils import timezone
    from datetime import timedelta
    from .models import Payment
    
    # Get date range
    today = timezone.now().date()
    thirty_days_ago = today - timedelta(days=30)
    
    if is_owner and not request.user.is_staff:
        # Owner-specific stats (only their office)
        office = request.user.offices.first()
        if not office:
            messages.error(request, "No office found for your account.")
            return redirect('owner_dashboard')
        
        total_cars = Car.objects.filter(office=office).count()
        total_bookings = Booking.objects.filter(car__office=office).count()
        recent_bookings = Booking.objects.filter(car__office=office, created_at__date__gte=thirty_days_ago).count()
        total_revenue = Payment.objects.filter(booking__car__office=office, status='paid').aggregate(total=Sum('amount'))['total'] or 0
        popular_cars = Car.objects.filter(office=office).annotate(booking_count=Count('bookings')).order_by('-booking_count')[:5]
        booking_stats = Booking.objects.filter(car__office=office).values('status').annotate(count=Count('id'))
        
        context = {
            'total_users': 0,  # Not relevant for owners
            'total_cars': total_cars,
            'total_bookings': total_bookings,
            'total_offices': 1,
            'recent_bookings': recent_bookings,
            'total_revenue': total_revenue,
            'popular_cars': popular_cars,
            'top_offices': [],
            'booking_stats': booking_stats,
            'is_owner_view': True,
            'office': office,
        }
    else:
        # Admin view - all stats
        total_users = User.objects.count()
        total_cars = Car.objects.count()
        total_bookings = Booking.objects.count()
        total_offices = Office.objects.filter(is_approved=True).count()
        recent_bookings = Booking.objects.filter(created_at__date__gte=thirty_days_ago).count()
        total_revenue = Payment.objects.filter(status='paid').aggregate(total=Sum('amount'))['total'] or 0
        popular_cars = Car.objects.annotate(booking_count=Count('bookings')).order_by('-booking_count')[:5]
        top_offices = Office.objects.filter(is_approved=True).order_by('-rating')[:5]
        booking_stats = Booking.objects.values('status').annotate(count=Count('id'))
        
        context = {
            'total_users': total_users,
            'total_cars': total_cars,
            'total_bookings': total_bookings,
            'total_offices': total_offices,
            'recent_bookings': recent_bookings,
            'total_revenue': total_revenue,
            'popular_cars': popular_cars,
            'top_offices': top_offices,
            'booking_stats': booking_stats,
        }
    
    return render(request, 'rentals/analytics_dashboard.html', context)


@login_required
def transaction_history_view(request):
    """Transaction history page - FR-18"""
    from .models import Payment
    
    payments = Payment.objects.filter(
        booking__user=request.user
    ).select_related('booking', 'booking__car').order_by('-created_at')
    
    return render(request, 'rentals/transaction_history.html', {'payments': payments})


@login_required
def request_extension_view(request, booking_id):
    """Request booking extension - FR-42"""
    from .models import BookingExtension
    from datetime import datetime
    
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    if booking.status not in ['confirmed', 'approved']:
        messages.error(request, "Cannot extend this booking.")
        return redirect('booking_list')
    
    if request.method == 'POST':
        new_end_date_str = request.POST.get('new_end_date', '')
        try:
            new_end_date = datetime.strptime(new_end_date_str, '%Y-%m-%d').date()
            
            if new_end_date <= booking.end_date:
                messages.error(request, "New end date must be after current end date.")
            elif not booking.car.is_available_for_dates(booking.end_date, new_end_date, booking.id):
                messages.error(request, "Car is not available for the requested dates.")
            else:
                extension = BookingExtension.objects.create(
                    booking=booking,
                    original_end_date=booking.end_date,
                    requested_end_date=new_end_date
                )
                extension.calculate_extra()
                extension.save()
                messages.success(request, f"Extension request submitted! Extra cost: {extension.extra_amount} JOD")
                return redirect('booking_list')
        except ValueError:
            messages.error(request, "Invalid date format.")
    
    return render(request, 'rentals/request_extension.html', {'booking': booking})


@login_required
def cancel_booking_view(request, booking_id):
    """Cancel a booking - FR-15"""
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    if booking.status in ['cancelled', 'completed']:
        messages.error(request, "This booking cannot be cancelled.")
        return redirect('booking_list')
    
    if request.method == 'POST':
        booking.status = 'cancelled'
        booking.save()
        
        # Create notification
        from .models import Notification
        Notification.objects.create(
            user=request.user,
            notification_type='booking_cancelled',
            channel='in_app',
            title='Booking Cancelled',
            message=f'Your booking {booking.booking_ref} has been cancelled.',
            data={'booking_id': booking.id}
        )
        
        messages.success(request, "Booking cancelled successfully.")
        return redirect('booking_list')
    
    return render(request, 'rentals/cancel_booking.html', {'booking': booking})


@login_required
def recommendations_view(request):
    """Personalized recommendations - FR-30"""
    from .models import RecommendationEvent
    
    # Get user's past bookings
    user_bookings = Booking.objects.filter(user=request.user).select_related('car')
    booked_car_ids = [b.car_id for b in user_bookings]
    
    # Get favorited cars
    favorite_car_ids = list(Favorite.objects.filter(user=request.user).values_list('car_id', flat=True))
    
    # Recommend similar cars
    recommendations = []
    
    # 1. Based on favorite brands
    if favorite_car_ids:
        fav_brands = Car.objects.filter(id__in=favorite_car_ids).values_list('brand', flat=True).distinct()
        brand_recommendations = Car.objects.filter(
            brand__in=fav_brands,
            is_available=True,
            office__is_approved=True
        ).exclude(id__in=favorite_car_ids + booked_car_ids)[:4]
        for car in brand_recommendations:
            recommendations.append({'car': car, 'reason': 'Similar to your favorites'})
    
    # 2. Top rated cars
    top_rated = Car.objects.filter(
        is_available=True,
        office__is_approved=True,
        avg_rating__gte=4.0
    ).exclude(id__in=booked_car_ids).order_by('-avg_rating')[:4]
    for car in top_rated:
        recommendations.append({'car': car, 'reason': 'Top rated'})
    
    # 3. Popular cars (most booked)
    from django.db.models import Count
    popular = Car.objects.filter(
        is_available=True,
        office__is_approved=True
    ).exclude(id__in=booked_car_ids).annotate(
        booking_count=Count('bookings')
    ).order_by('-booking_count')[:4]
    for car in popular:
        recommendations.append({'car': car, 'reason': 'Popular choice'})
    
    return render(request, 'rentals/recommendations.html', {'recommendations': recommendations[:12]})


def car_map_view(request):
    """Map view of available cars - FR-26"""
    cars = Car.objects.filter(
        is_available=True,
        office__is_approved=True,
        lat__isnull=False,
        lng__isnull=False
    ).select_related('office')
    
    offices = Office.objects.filter(
        is_approved=True,
        is_blocked=False,
        lat__isnull=False,
        lng__isnull=False
    )
    
    # Prepare data for map
    car_markers = []
    for car in cars:
        car_markers.append({
            'id': car.id,
            'lat': float(car.lat) if car.lat else None,
            'lng': float(car.lng) if car.lng else None,
            'title': f"{car.brand} {car.model}",
            'price': float(car.price_per_day),
            'url': f"/car/{car.id}/"
        })
    
    office_markers = []
    for office in offices:
        office_markers.append({
            'id': office.id,
            'lat': float(office.lat) if office.lat else None,
            'lng': float(office.lng) if office.lng else None,
            'name': office.name,
            'rating': office.rating
        })
    
    context = {
        'car_markers': json.dumps(car_markers),
        'office_markers': json.dumps(office_markers),
    }
    
    return render(request, 'rentals/car_map.html', context)


@login_required
def damage_report_view(request, booking_id, report_type):
    """Pre/Post rental damage report - FR-43, FR-44"""
    from .models import DamageReport, DamageReportImage
    
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    # Check if report already exists
    existing = DamageReport.objects.filter(
        booking=booking, 
        report_type='pre_rental' if report_type == 'pre' else 'post_rental'
    ).first()
    
    if existing:
        messages.info(request, 'A damage report already exists for this booking.')
        return redirect('booking_list')
    
    if request.method == 'POST':
        report = DamageReport.objects.create(
            booking=booking,
            report_type='pre_rental' if report_type == 'pre' else 'post_rental',
            reporter=request.user,
            reported_by='renter',
            notes=request.POST.get('notes', ''),
            fuel_level=request.POST.get('fuel_level', ''),
            mileage=request.POST.get('mileage') or None,
            has_damage=request.POST.get('has_damage') == 'true',
            damage_description=request.POST.get('damage_description', ''),
            estimated_repair_cost=request.POST.get('estimated_repair_cost') or None
        )
        
        # Handle image uploads
        for image in request.FILES.getlist('images'):
            DamageReportImage.objects.create(
                damage_report=report,
                image=image,
                caption=f"Damage photo for {booking.booking_ref}"
            )
        
        messages.success(request, 'Damage report submitted successfully!')
        return redirect('booking_list')
    
    return render(request, 'rentals/damage_report.html', {
        'booking': booking,
        'report_type': report_type
    })


@login_required
def download_receipt_view(request, payment_id):
    """Download receipt as PDF - FR-17"""
    from .models import Payment, Receipt
    from django.http import HttpResponse
    from django.template.loader import render_to_string
    
    payment = get_object_or_404(Payment, id=payment_id, booking__user=request.user)
    
    # Get or create receipt
    receipt, created = Receipt.objects.get_or_create(payment=payment)
    
    # Generate HTML receipt
    html_content = render_to_string('rentals/receipt_pdf.html', {
        'payment': payment,
        'receipt': receipt,
        'booking': payment.booking,
        'car': payment.booking.car,
    })
    
    # For simplicity, return HTML receipt (in production, use weasyprint/xhtml2pdf for PDF)
    response = HttpResponse(html_content, content_type='text/html')
    response['Content-Disposition'] = f'attachment; filename="receipt_{payment.provider_txn_id}.html"'
    
    return response


@login_required
def review_moderation_view(request):
    """Admin review moderation - FR-25"""
    from .models import Review
    
    if not request.user.is_staff:
        return HttpResponseForbidden("Admin access required.")
    
    if request.method == 'POST':
        review_id = request.POST.get('review_id')
        action = request.POST.get('action')
        
        review = get_object_or_404(Review, id=review_id)
        
        if action == 'approve':
            review.status = 'approved'
            review.moderated_by = request.user
            review.save()
            
            # Update car's average rating
            review.car.update_rating()
            
            messages.success(request, f'Review approved.')
        elif action == 'reject':
            review.status = 'rejected'
            review.moderated_by = request.user
            review.save()
            messages.info(request, f'Review rejected.')
        
        return redirect('review_moderation')
    
    # Get pending reviews
    pending_reviews = Review.objects.filter(status='pending').select_related(
        'user', 'car', 'booking'
    ).order_by('-created_at')
    
    # Get recent moderated reviews
    moderated_reviews = Review.objects.exclude(status='pending').select_related(
        'user', 'car', 'moderated_by'
    ).order_by('-created_at')[:20]
    
    return render(request, 'rentals/review_moderation.html', {
        'pending_reviews': pending_reviews,
        'moderated_reviews': moderated_reviews
    })


@login_required
def upload_insurance_view(request, car_id):
    """Upload car insurance document - FR-39"""
    from .models import CarInsuranceDoc
    
    car = get_object_or_404(Car, id=car_id, office__owner=request.user)
    
    if request.method == 'POST':
        doc_type = request.POST.get('doc_type', 'insurance')
        expiry_date = request.POST.get('expiry_date', '')
        document = request.FILES.get('document')
        
        if document:
            from datetime import datetime
            exp_date = None
            if expiry_date:
                try:
                    exp_date = datetime.strptime(expiry_date, '%Y-%m-%d').date()
                except ValueError:
                    pass
            
            CarInsuranceDoc.objects.create(
                car=car,
                doc_type=doc_type,
                document=document,
                expiry_date=exp_date
            )
            messages.success(request, 'Document uploaded successfully!')
            return redirect('edit_car', car_id=car.id)
        else:
            messages.error(request, 'Please select a file to upload.')
    
    # Get existing documents
    documents = CarInsuranceDoc.objects.filter(car=car).order_by('-uploaded_at')
    
    return render(request, 'rentals/upload_insurance.html', {
        'car': car,
        'documents': documents
    })


@login_required
def rental_agreement_view(request, booking_id):
    """Digital rental agreement - FR-40"""
    from .models import RentalAgreement
    from django.utils import timezone
    
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    # Check for existing agreement
    agreement = RentalAgreement.objects.filter(booking=booking).first()
    
    if request.method == 'POST':
        if not agreement:
            agreement = RentalAgreement.objects.create(
                booking=booking,
                terms_text="""
RENTAL AGREEMENT TERMS AND CONDITIONS

1. The renter agrees to return the vehicle in the same condition as received.
2. The renter is responsible for any traffic violations during the rental period.
3. The vehicle must not be taken outside the agreed-upon geographic area.
4. The renter must maintain adequate fuel levels.
5. Any damage must be reported immediately.
6. Insurance coverage as per the selected plan applies.
7. The renter must present a valid driver's license at pickup.
8. Late returns may incur additional charges.
"""
            )
        
        signature_data = request.POST.get('signature', '')
        
        if signature_data:
            agreement.renter_signature = signature_data
            agreement.renter_signed_at = timezone.now()
            agreement.save()
            
            messages.success(request, 'Agreement signed successfully!')
            return redirect('booking_list')
        else:
            messages.error(request, 'Please provide your signature.')
    
    return render(request, 'rentals/rental_agreement.html', {
        'booking': booking,
        'agreement': agreement
    })
