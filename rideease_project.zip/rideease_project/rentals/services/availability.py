"""
Availability Service for RideEase

Handles car availability checking and booking conflict detection.
"""

from datetime import date, timedelta
from typing import List, Optional, Tuple

from django.db.models import Q

from ..models import Booking, Car


class AvailabilityService:
    """Service for managing car availability"""
    
    @staticmethod
    def is_car_available(car_id: int, start_date: date, end_date: date, 
                         exclude_booking_id: Optional[int] = None) -> bool:
        """
        Check if a car is available for the given date range
        
        Args:
            car_id: ID of the car to check
            start_date: Start date of the desired rental
            end_date: End date of the desired rental
            exclude_booking_id: Optional booking ID to exclude (for modifications)
            
        Returns:
            True if available, False otherwise
        """
        try:
            car = Car.objects.get(id=car_id)
        except Car.DoesNotExist:
            return False
        
        # Check if car is generally available
        if not car.is_available:
            return False
        
        # Check for overlapping bookings
        # A booking overlaps if: existing_start <= new_end AND existing_end >= new_start
        overlapping = Booking.objects.filter(
            car_id=car_id,
            status__in=['pending', 'confirmed', 'approved'],
            start_date__lte=end_date,
            end_date__gte=start_date
        )
        
        if exclude_booking_id:
            overlapping = overlapping.exclude(id=exclude_booking_id)
        
        return not overlapping.exists()
    
    @staticmethod
    def get_booked_dates(car_id: int, start_date: date, end_date: date) -> List[date]:
        """
        Get list of dates that are already booked for a car
        
        Args:
            car_id: ID of the car
            start_date: Start of date range to check
            end_date: End of date range to check
            
        Returns:
            List of dates that are booked
        """
        bookings = Booking.objects.filter(
            car_id=car_id,
            status__in=['pending', 'confirmed', 'approved'],
            start_date__lte=end_date,
            end_date__gte=start_date
        )
        
        booked_dates = set()
        for booking in bookings:
            current = max(booking.start_date, start_date)
            booking_end = min(booking.end_date, end_date)
            while current <= booking_end:
                booked_dates.add(current)
                current += timedelta(days=1)
        
        return sorted(list(booked_dates))
    
    @staticmethod
    def get_available_dates(car_id: int, start_date: date, end_date: date) -> List[date]:
        """
        Get list of available dates for a car
        
        Args:
            car_id: ID of the car
            start_date: Start of date range to check
            end_date: End of date range to check
            
        Returns:
            List of available dates
        """
        booked = set(AvailabilityService.get_booked_dates(car_id, start_date, end_date))
        
        available_dates = []
        current = start_date
        while current <= end_date:
            if current not in booked:
                available_dates.append(current)
            current += timedelta(days=1)
        
        return available_dates
    
    @staticmethod
    def find_next_available_slot(car_id: int, desired_days: int, 
                                  search_start: Optional[date] = None,
                                  max_search_days: int = 90) -> Optional[Tuple[date, date]]:
        """
        Find the next available slot for a given number of days
        
        Args:
            car_id: ID of the car
            desired_days: Number of consecutive days needed
            search_start: Date to start searching from (defaults to today)
            max_search_days: Maximum days to search ahead
            
        Returns:
            Tuple of (start_date, end_date) if found, None otherwise
        """
        if search_start is None:
            search_start = date.today()
        
        search_end = search_start + timedelta(days=max_search_days)
        booked = set(AvailabilityService.get_booked_dates(car_id, search_start, search_end))
        
        current = search_start
        consecutive_count = 0
        slot_start = None
        
        while current <= search_end:
            if current not in booked:
                if slot_start is None:
                    slot_start = current
                consecutive_count += 1
                
                if consecutive_count >= desired_days:
                    return (slot_start, slot_start + timedelta(days=desired_days - 1))
            else:
                consecutive_count = 0
                slot_start = None
            
            current += timedelta(days=1)
        
        return None
    
    @staticmethod
    def get_availability_calendar(car_id: int, month: int, year: int) -> dict:
        """
        Get availability calendar for a specific month
        
        Args:
            car_id: ID of the car
            month: Month (1-12)
            year: Year
            
        Returns:
            Dict with date as key and availability status as value
        """
        from calendar import monthrange
        
        _, num_days = monthrange(year, month)
        start_date = date(year, month, 1)
        end_date = date(year, month, num_days)
        
        booked = set(AvailabilityService.get_booked_dates(car_id, start_date, end_date))
        
        calendar = {}
        current = start_date
        while current <= end_date:
            calendar[current.isoformat()] = {
                'date': current.isoformat(),
                'available': current not in booked,
                'past': current < date.today()
            }
            current += timedelta(days=1)
        
        return calendar
    
    @staticmethod
    def can_extend_booking(booking_id: int, new_end_date: date) -> Tuple[bool, str]:
        """
        Check if a booking can be extended to a new end date
        
        Args:
            booking_id: ID of the booking to extend
            new_end_date: Desired new end date
            
        Returns:
            Tuple of (can_extend, reason)
        """
        try:
            booking = Booking.objects.get(id=booking_id)
        except Booking.DoesNotExist:
            return (False, "Booking not found")
        
        if booking.status not in ['confirmed', 'approved']:
            return (False, "Can only extend confirmed or approved bookings")
        
        if new_end_date <= booking.end_date:
            return (False, "New end date must be after current end date")
        
        # Check if extension period is available
        is_available = AvailabilityService.is_car_available(
            booking.car_id,
            booking.end_date + timedelta(days=1),
            new_end_date,
            exclude_booking_id=booking_id
        )
        
        if not is_available:
            return (False, "Car is not available for the extension period")
        
        return (True, "Extension available")
    
    @staticmethod
    def get_cars_available_for_dates(start_date: date, end_date: date, 
                                      filters: Optional[dict] = None) -> List[Car]:
        """
        Get all cars that are available for the given date range
        
        Args:
            start_date: Start date
            end_date: End date
            filters: Optional additional filters (brand, fuel_type, etc.)
            
        Returns:
            QuerySet of available cars
        """
        # Get cars with conflicting bookings
        conflicting_car_ids = Booking.objects.filter(
            status__in=['pending', 'confirmed', 'approved'],
            start_date__lte=end_date,
            end_date__gte=start_date
        ).values_list('car_id', flat=True)
        
        # Base query
        cars = Car.objects.filter(
            is_available=True,
            office__is_approved=True,
            office__is_blocked=False
        ).exclude(id__in=conflicting_car_ids)
        
        # Apply additional filters
        if filters:
            if filters.get('brand'):
                cars = cars.filter(brand__icontains=filters['brand'])
            if filters.get('fuel_type'):
                cars = cars.filter(fuel_type=filters['fuel_type'])
            if filters.get('transmission_type'):
                cars = cars.filter(transmission_type=filters['transmission_type'])
            if filters.get('body_type'):
                cars = cars.filter(body_type=filters['body_type'])
            if filters.get('min_price'):
                cars = cars.filter(price_per_day__gte=filters['min_price'])
            if filters.get('max_price'):
                cars = cars.filter(price_per_day__lte=filters['max_price'])
            if filters.get('min_seats'):
                cars = cars.filter(number_of_seats__gte=filters['min_seats'])
            if filters.get('office_id'):
                cars = cars.filter(office_id=filters['office_id'])
        
        return cars


def is_car_available(car_id: int, start_date: date, end_date: date, 
                     exclude_booking_id: Optional[int] = None) -> bool:
    """Convenience function for checking car availability"""
    return AvailabilityService.is_car_available(car_id, start_date, end_date, exclude_booking_id)


def get_availability_calendar(car_id: int, month: int, year: int) -> dict:
    """Convenience function for getting availability calendar"""
    return AvailabilityService.get_availability_calendar(car_id, month, year)


def can_extend_booking(booking_id: int, new_end_date: date) -> Tuple[bool, str]:
    """Convenience function for checking booking extension"""
    return AvailabilityService.can_extend_booking(booking_id, new_end_date)
