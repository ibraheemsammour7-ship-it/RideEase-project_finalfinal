"""
Notification Service for RideEase

Handles sending notifications via email, SMS, and in-app.
"""

from typing import Optional, Dict, Any
from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils import timezone

from ..models import Notification, User, Booking


class NotificationService:
    """Service for managing and sending notifications"""
    
    # Notification templates
    TEMPLATES = {
        'booking_confirmed': {
            'title': 'Booking Confirmed',
            'message': 'Your booking {booking_ref} has been confirmed. Pickup on {start_date}.',
        },
        'booking_cancelled': {
            'title': 'Booking Cancelled',
            'message': 'Your booking {booking_ref} has been cancelled.',
        },
        'payment_success': {
            'title': 'Payment Successful',
            'message': 'Your payment of {amount} {currency} for booking {booking_ref} was successful.',
        },
        'payment_failed': {
            'title': 'Payment Failed',
            'message': 'Your payment for booking {booking_ref} failed. Please try again.',
        },
        'review_approved': {
            'title': 'Review Published',
            'message': 'Your review has been approved and published.',
        },
        'extension_approved': {
            'title': 'Extension Approved',
            'message': 'Your booking extension request has been approved. New end date: {new_end_date}.',
        },
        'extension_rejected': {
            'title': 'Extension Rejected',
            'message': 'Your booking extension request has been rejected.',
        },
        'reminder': {
            'title': 'Rental Reminder',
            'message': 'Reminder: Your rental for {car_name} starts on {start_date}.',
        },
    }
    
    @classmethod
    def create_notification(cls, 
                           user: User, 
                           notification_type: str, 
                           channel: str = 'in_app',
                           data: Optional[Dict[str, Any]] = None,
                           custom_title: Optional[str] = None,
                           custom_message: Optional[str] = None) -> Notification:
        """
        Create a notification for a user
        
        Args:
            user: User to notify
            notification_type: Type of notification (from TEMPLATES)
            channel: Delivery channel (email, sms, in_app)
            data: Optional data to interpolate into message
            custom_title: Optional custom title override
            custom_message: Optional custom message override
            
        Returns:
            Created Notification instance
        """
        data = data or {}
        
        # Get template or use custom
        template = cls.TEMPLATES.get(notification_type, {})
        title = custom_title or template.get('title', 'Notification')
        message = custom_message or template.get('message', '')
        
        # Interpolate data into message
        try:
            message = message.format(**data)
        except KeyError:
            pass  # Keep original message if interpolation fails
        
        notification = Notification.objects.create(
            user=user,
            notification_type=notification_type,
            channel=channel,
            title=title,
            message=message,
            data=data
        )
        
        # Send based on channel
        if channel == 'email':
            cls.send_email(notification)
        elif channel == 'sms':
            cls.send_sms(notification)
        
        return notification
    
    @classmethod
    def send_email(cls, notification: Notification) -> bool:
        """
        Send notification via email
        
        Args:
            notification: Notification instance
            
        Returns:
            True if sent successfully
        """
        try:
            send_mail(
                subject=notification.title,
                message=notification.message,
                from_email=settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@rideease.com',
                recipient_list=[notification.user.email],
                fail_silently=True
            )
            notification.sent_at = timezone.now()
            notification.save()
            return True
        except Exception as e:
            print(f"Email send failed: {e}")
            return False
    
    @classmethod
    def send_sms(cls, notification: Notification) -> bool:
        """
        Send notification via SMS
        
        Args:
            notification: Notification instance
            
        Returns:
            True if sent successfully
            
        Note: This is a placeholder. In production, integrate with
        Twilio, Nexmo, or another SMS provider.
        """
        # Placeholder - integrate with SMS provider
        if hasattr(notification.user, 'profile') and notification.user.profile.phone:
            # Example Twilio integration:
            # from twilio.rest import Client
            # client = Client(TWILIO_SID, TWILIO_TOKEN)
            # client.messages.create(
            #     body=notification.message,
            #     from_=TWILIO_PHONE,
            #     to=notification.user.profile.phone
            # )
            print(f"SMS to {notification.user.profile.phone}: {notification.message}")
            notification.sent_at = timezone.now()
            notification.save()
            return True
        return False
    
    @classmethod
    def notify_booking_confirmed(cls, booking: Booking) -> None:
        """Send booking confirmation notifications"""
        data = {
            'booking_ref': booking.booking_ref,
            'start_date': booking.start_date.strftime('%B %d, %Y'),
            'end_date': booking.end_date.strftime('%B %d, %Y'),
            'car_name': str(booking.car),
        }
        
        # Notify renter
        cls.create_notification(
            user=booking.user,
            notification_type='booking_confirmed',
            channel='in_app',
            data=data
        )
        cls.create_notification(
            user=booking.user,
            notification_type='booking_confirmed',
            channel='email',
            data=data
        )
        
        # Notify supplier
        if booking.supplier:
            cls.create_notification(
                user=booking.supplier,
                notification_type='booking_confirmed',
                channel='in_app',
                data=data,
                custom_title='New Booking',
                custom_message=f'New booking {booking.booking_ref} from {booking.customer_name}'
            )
    
    @classmethod
    def notify_booking_cancelled(cls, booking: Booking, refund_info: Optional[dict] = None) -> None:
        """Send booking cancellation notifications"""
        data = {
            'booking_ref': booking.booking_ref,
            'refund_amount': refund_info.get('refund_amount', 0) if refund_info else 0,
            'currency': refund_info.get('currency', 'JOD') if refund_info else 'JOD',
        }
        
        message = f'Your booking {booking.booking_ref} has been cancelled.'
        if refund_info and refund_info.get('refund_amount'):
            message += f' A refund of {data["refund_amount"]} {data["currency"]} will be processed.'
        
        cls.create_notification(
            user=booking.user,
            notification_type='booking_cancelled',
            channel='in_app',
            data=data,
            custom_message=message
        )
    
    @classmethod
    def notify_payment_success(cls, payment) -> None:
        """Send payment success notification"""
        data = {
            'amount': float(payment.amount),
            'currency': payment.currency,
            'booking_ref': payment.booking.booking_ref,
        }
        
        cls.create_notification(
            user=payment.user,
            notification_type='payment_success',
            channel='in_app',
            data=data
        )
        cls.create_notification(
            user=payment.user,
            notification_type='payment_success',
            channel='email',
            data=data
        )
    
    @classmethod
    def notify_review_approved(cls, review) -> None:
        """Send review approval notification"""
        cls.create_notification(
            user=review.user,
            notification_type='review_approved',
            channel='in_app',
            data={'car_name': str(review.car)}
        )
    
    @classmethod
    def notify_extension_decision(cls, extension, approved: bool) -> None:
        """Send extension decision notification"""
        notification_type = 'extension_approved' if approved else 'extension_rejected'
        data = {
            'booking_ref': extension.booking.booking_ref,
            'new_end_date': extension.requested_end_date.strftime('%B %d, %Y'),
        }
        
        cls.create_notification(
            user=extension.booking.user,
            notification_type=notification_type,
            channel='in_app',
            data=data
        )
    
    @classmethod
    def send_rental_reminder(cls, booking: Booking, days_before: int = 1) -> None:
        """Send rental reminder"""
        data = {
            'booking_ref': booking.booking_ref,
            'start_date': booking.start_date.strftime('%B %d, %Y'),
            'car_name': str(booking.car),
        }
        
        cls.create_notification(
            user=booking.user,
            notification_type='reminder',
            channel='in_app',
            data=data
        )
        cls.create_notification(
            user=booking.user,
            notification_type='reminder',
            channel='email',
            data=data
        )
    
    @staticmethod
    def get_unread_count(user: User) -> int:
        """Get count of unread notifications for a user"""
        return Notification.objects.filter(user=user, is_read=False).count()
    
    @staticmethod
    def mark_all_read(user: User) -> int:
        """Mark all notifications as read for a user"""
        return Notification.objects.filter(user=user, is_read=False).update(
            is_read=True,
            read_at=timezone.now()
        )


# Convenience functions
def notify_booking_confirmed(booking: Booking) -> None:
    """Send booking confirmation notification"""
    NotificationService.notify_booking_confirmed(booking)


def notify_booking_cancelled(booking: Booking, refund_info: Optional[dict] = None) -> None:
    """Send booking cancellation notification"""
    NotificationService.notify_booking_cancelled(booking, refund_info)


def notify_payment_success(payment) -> None:
    """Send payment success notification"""
    NotificationService.notify_payment_success(payment)
