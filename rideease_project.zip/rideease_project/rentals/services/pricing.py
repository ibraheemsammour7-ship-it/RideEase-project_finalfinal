"""
Pricing Service for RideEase

Handles all pricing calculations including:
- Rental cost calculation
- Discount application
- Late fee calculation
- Refund calculation
"""

from decimal import Decimal
from django.conf import settings
from django.utils import timezone

from ..models import Booking, Discount, PolicyConfig


class PricingService:
    """Service for calculating prices, discounts, and fees"""
    
    @staticmethod
    def get_settings():
        """Get business settings"""
        return getattr(settings, 'RIDEEASE_SETTINGS', {
            'CURRENCY': 'JOD',
            'CANCELLATION_POLICY': {
                'full_refund_days': 7,
                'partial_refund_days': 3,
                'partial_refund_percent': 50,
            },
            'LATE_FEE_MULTIPLIER': 1.5,
        })
    
    @classmethod
    def calculate_rental_cost(cls, car, start_date, end_date, discount_code=None):
        """
        Calculate the total rental cost for a car
        
        Args:
            car: Car instance
            start_date: Start date of rental
            end_date: End date of rental  
            discount_code: Optional discount code to apply
            
        Returns:
            dict with pricing breakdown
        """
        # Calculate days
        num_days = (end_date - start_date).days + 1
        if num_days < 1:
            num_days = 1
        
        # Base calculation
        daily_rate = car.price_per_day
        subtotal = daily_rate * num_days
        
        # Calculate discount
        discount_amount = Decimal('0.00')
        discount_info = None
        
        if discount_code:
            discount = cls.get_valid_discount(discount_code, car, subtotal, num_days)
            if discount:
                discount_amount = discount.calculate_discount(subtotal)
                discount_info = {
                    'code': discount.code,
                    'name': discount.name,
                    'type': discount.discount_type,
                    'value': float(discount.value),
                    'amount': float(discount_amount)
                }
        
        # Calculate total
        total = subtotal - discount_amount
        
        return {
            'daily_rate': float(daily_rate),
            'num_days': num_days,
            'subtotal': float(subtotal),
            'discount': discount_info,
            'discount_amount': float(discount_amount),
            'total': float(total),
            'currency': cls.get_settings().get('CURRENCY', 'JOD')
        }
    
    @classmethod
    def get_valid_discount(cls, code, car, amount, num_days):
        """
        Check if a discount code is valid and applicable
        
        Args:
            code: Discount code string
            car: Car the discount would apply to
            amount: Order amount
            num_days: Number of rental days
            
        Returns:
            Discount instance if valid, None otherwise
        """
        try:
            discount = Discount.objects.get(code=code.upper())
        except Discount.DoesNotExist:
            return None
        
        # Check if discount is valid
        if not discount.is_valid():
            return None
        
        # Check minimum days
        if num_days < discount.min_rental_days:
            return None
        
        # Check minimum amount
        if amount < discount.min_amount:
            return None
        
        # Check if applicable to this car
        if discount.applicable_cars.exists():
            if not discount.applicable_cars.filter(id=car.id).exists():
                return None
        
        # Check if applicable to this office
        if discount.applicable_offices.exists():
            if not discount.applicable_offices.filter(id=car.office_id).exists():
                return None
        
        return discount
    
    @classmethod
    def calculate_late_fee(cls, booking, actual_return_date):
        """
        Calculate late return fee
        
        Args:
            booking: Booking instance
            actual_return_date: Actual date the car was returned
            
        Returns:
            Late fee amount
        """
        if actual_return_date <= booking.end_date:
            return Decimal('0.00')
        
        late_days = (actual_return_date - booking.end_date).days
        multiplier = Decimal(str(cls.get_settings().get('LATE_FEE_MULTIPLIER', 1.5)))
        
        late_fee = booking.daily_rate * late_days * multiplier
        
        return late_fee
    
    @classmethod
    def calculate_extension_cost(cls, booking, new_end_date):
        """
        Calculate cost of extending a booking
        
        Args:
            booking: Booking instance
            new_end_date: New end date
            
        Returns:
            dict with extension pricing
        """
        if new_end_date <= booking.end_date:
            return None
        
        extra_days = (new_end_date - booking.end_date).days
        extra_cost = booking.daily_rate * extra_days
        
        return {
            'original_end_date': booking.end_date.isoformat(),
            'new_end_date': new_end_date.isoformat(),
            'extra_days': extra_days,
            'daily_rate': float(booking.daily_rate),
            'extra_cost': float(extra_cost),
            'currency': cls.get_settings().get('CURRENCY', 'JOD')
        }
    
    @classmethod
    def calculate_refund(cls, booking, cancellation_date=None):
        """
        Calculate refund amount based on cancellation policy
        
        Args:
            booking: Booking instance
            cancellation_date: Date of cancellation (defaults to now)
            
        Returns:
            dict with refund details
        """
        if cancellation_date is None:
            cancellation_date = timezone.now().date()
        
        policy = cls.get_settings().get('CANCELLATION_POLICY', {})
        full_refund_days = policy.get('full_refund_days', 7)
        partial_refund_days = policy.get('partial_refund_days', 3)
        partial_refund_percent = policy.get('partial_refund_percent', 50)
        
        days_until_start = (booking.start_date - cancellation_date).days
        
        # Determine refund percentage
        if days_until_start >= full_refund_days:
            refund_percent = 100
            reason = f"Cancelled {days_until_start} days before start (>= {full_refund_days} days)"
        elif days_until_start >= partial_refund_days:
            refund_percent = partial_refund_percent
            reason = f"Cancelled {days_until_start} days before start ({partial_refund_days}-{full_refund_days} days)"
        else:
            refund_percent = 0
            reason = f"Cancelled {days_until_start} days before start (< {partial_refund_days} days)"
        
        # Get total paid amount
        total_paid = sum(
            p.amount for p in booking.payments.filter(status='paid')
        )
        
        refund_amount = total_paid * Decimal(refund_percent) / 100
        
        return {
            'days_until_start': days_until_start,
            'refund_percent': refund_percent,
            'total_paid': float(total_paid),
            'refund_amount': float(refund_amount),
            'reason': reason,
            'currency': cls.get_settings().get('CURRENCY', 'JOD')
        }
    
    @classmethod
    def apply_discount_to_booking(cls, booking, discount_code):
        """
        Apply a discount code to an existing booking
        
        Args:
            booking: Booking instance
            discount_code: Discount code to apply
            
        Returns:
            Updated booking or None if discount invalid
        """
        discount = cls.get_valid_discount(
            discount_code, 
            booking.car, 
            booking.subtotal, 
            booking.num_days
        )
        
        if not discount:
            return None
        
        booking.discount_amount = discount.calculate_discount(booking.subtotal)
        booking.total_amount = booking.subtotal - booking.discount_amount
        booking.save()
        
        # Increment discount usage
        discount.current_uses += 1
        discount.save()
        
        return booking


def calculate_rental_cost(car, start_date, end_date, discount_code=None):
    """Convenience function for calculating rental cost"""
    return PricingService.calculate_rental_cost(car, start_date, end_date, discount_code)


def calculate_refund(booking, cancellation_date=None):
    """Convenience function for calculating refunds"""
    return PricingService.calculate_refund(booking, cancellation_date)


def calculate_late_fee(booking, actual_return_date):
    """Convenience function for calculating late fees"""
    return PricingService.calculate_late_fee(booking, actual_return_date)
