# seed_data.py
import django
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rideease_backend.settings')
django.setup()

from django.contrib.auth.models import User
from rentals.models import Office, Car, Profile

# إنشاء مستخدمين تجريبيين
owner1, _ = User.objects.get_or_create(username='office_admin1', defaults={'email': 'admin1@office.com'})
owner2, _ = User.objects.get_or_create(username='office_admin2', defaults={'email': 'admin2@office.com'})

# تأكيد أنهم عندهم profile كصاحب مكتب
Profile.objects.get_or_create(user=owner1, defaults={'user_type': 'owner'})
Profile.objects.get_or_create(user=owner2, defaults={'user_type': 'owner'})

# مكاتب
office1, _ = Office.objects.get_or_create(name='Amman Wheels', location='Amman', owner=owner1)
office2, _ = Office.objects.get_or_create(name='Irbid Drive', location='Irbid', owner=owner2)

# سيارات لكل مكتب
cars = [
    {"brand": "Toyota", "model": "Corolla", "year": 2020, "price_per_day": 25.0, "location": "Amman", "office": office1},
    {"brand": "Hyundai", "model": "Elantra", "year": 2019, "price_per_day": 22.0, "location": "Amman", "office": office1},
    {"brand": "Kia", "model": "Sportage", "year": 2021, "price_per_day": 35.0, "location": "Irbid", "office": office2},
    {"brand": "Tesla", "model": "Model 3", "year": 2022, "price_per_day": 50.0, "location": "Irbid", "office": office2},
]

for car_data in cars:
    Car.objects.get_or_create(**car_data)

print("✅ Demo data seeded successfully.")
