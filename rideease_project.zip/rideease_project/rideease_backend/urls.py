from django.contrib import admin
from django.urls import path, include
from rentals.views import (
    car_detail, book_car, booking_list,
    delete_booking, edit_booking, rental_request_view, terms_view
)
from django.contrib.auth import views as auth_views
from rentals import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    # =============================================
    # API ROUTES
    # =============================================
    path('api/', include('rentals.api.urls')),
    
    # =============================================
    # WEB ROUTES
    # =============================================
    
    # Home page - office list
    path('', views.office_list, name='office_list'),

    # Cars and bookings
    path('car/<int:car_id>/', car_detail, name='car_detail'),
    path('car/<int:car_id>/book/', book_car, name='book_car'),
    path('bookings/', booking_list, name='booking_list'),
    path('bookings/delete/<int:booking_id>/', delete_booking, name='delete_booking'),
    path('bookings/edit/<int:booking_id>/', edit_booking, name='edit_booking'),
    path('bookings/history/', views.booking_history_view, name='booking_history'),
    path('bookings/<int:booking_id>/pay/', views.payment_page, name='payment_page'),
    path('bookings/<int:booking_id>/review/', views.review_booking, name='review_booking'),
    path('favorites/', views.favorites_view, name='favorites'),

    # Auth
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.register_view, name='register'),

    # Owner/Supplier dashboard
    path('owner/dashboard/', views.owner_dashboard, name='owner_dashboard'),
    path('owner/add-car/', views.add_car, name='add_car'),
    path('owner/edit-car/<int:car_id>/', views.edit_car, name='edit_car'),
    path('owner/delete-car/<int:car_id>/', views.delete_car, name='delete_car'),

    # Office ratings
    path('office/<int:office_id>/rate/', views.rate_office, name='rate_office'),
    path('office/<int:office_id>/rate/ajax/', views.ajax_rate_office, name='ajax_rate_office'),
    path('prototype/', views.prototype_view, name='prototype'),

    # Offices and cars listing
    path('offices/', views.office_list, name='office_list'),
    path('offices/<int:office_id>/', views.office_cars, name='office_cars'),
    path('cars/', views.car_list, name='car_list'),

    # Booking approval/rejection
    path('booking/<int:booking_id>/approve/', views.approve_booking, name='approve_booking'),
    path('booking/<int:booking_id>/reject/', views.reject_booking, name='reject_booking'),

    # Partner signup
    path('partner-signup/', views.partner_signup_view, name='partner_signup'),
    path('company-documents/', views.company_documents_view, name='company_documents_page'),
    path('submission-success/', views.partner_thank_you_view, name='partner_thank_you'),

    path('rental-request/', rental_request_view, name='rental_request'),
    path('terms/', terms_view, name='terms'),

    # Password reset
    path('password-reset/', auth_views.PasswordResetView.as_view(
        template_name='rentals/password_reset.html'
    ), name='password_reset'),

    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(
        template_name='rentals/password_reset_done.html'
    ), name='password_reset_done'),

    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
        template_name='rentals/password_reset_confirm.html'
    ), name='password_reset_confirm'),

    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(
        template_name='rentals/password_reset_complete.html'
    ), name='password_reset_complete'),

    # =============================================
    # NEW ROUTES - All Requirements Implementation
    # =============================================
    
    # Profile and Account (FR-4, FR-34)
    path('profile/edit/', views.edit_profile_view, name='edit_profile'),
    path('account/delete/', views.delete_account_view, name='delete_account'),
    
    # Support and Information (FR-37, FR-48)
    path('faq/', views.faq_view, name='faq'),
    path('support/', views.contact_support_view, name='contact_support'),
    
    # Notifications (FR-28)
    path('notifications/', views.notifications_view, name='notifications'),
    
    # Analytics Dashboard (FR-24)
    path('admin/analytics/', views.analytics_dashboard_view, name='analytics_dashboard'),
    
    # Transaction History (FR-18)
    path('transactions/', views.transaction_history_view, name='transaction_history'),
    
    # Booking Extensions and Cancellation (FR-42, FR-15)
    path('bookings/<int:booking_id>/extend/', views.request_extension_view, name='request_extension'),
    path('bookings/<int:booking_id>/cancel/', views.cancel_booking_view, name='cancel_booking'),
    
    # Recommendations (FR-30)
    path('recommendations/', views.recommendations_view, name='recommendations'),
    
    # Map View (FR-26)
    path('map/', views.car_map_view, name='car_map'),
    
    # Damage Reports (FR-43, FR-44)
    path('bookings/<int:booking_id>/damage/<str:report_type>/', views.damage_report_view, name='damage_report'),
    
    # Receipt Download (FR-17)
    path('receipt/<int:payment_id>/download/', views.download_receipt_view, name='download_receipt'),
    
    # Review Moderation (FR-25)
    path('admin/reviews/', views.review_moderation_view, name='review_moderation'),
    
    # Insurance Upload (FR-39)
    path('car/<int:car_id>/insurance/', views.upload_insurance_view, name='upload_insurance'),
    
    # Rental Agreement (FR-40)
    path('bookings/<int:booking_id>/agreement/', views.rental_agreement_view, name='rental_agreement'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
