import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'rideease_backend.settings')
import django
django.setup()

from rentals.models import OfficeRating

# Find and remove duplicate ratings
dupes = OfficeRating.objects.filter(office_id=1, user_id=9).order_by('id')
print(f'Before: {dupes.count()} ratings for office 1, user 9')

# Keep the first one, delete the rest
ids_to_keep = [dupes.first().id] if dupes.exists() else []
if dupes.count() > 1:
    OfficeRating.objects.filter(office_id=1, user_id=9).exclude(id__in=ids_to_keep).delete()
    print(f'After: {OfficeRating.objects.filter(office_id=1, user_id=9).count()} ratings')

print('Done!')
